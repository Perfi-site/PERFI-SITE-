---
name: Imported editor workspace recovery
description: A workflow startup check for the tracked imported Next.js application.
---

The PERFI-SITE Next.js app is tracked under `.conversation`, separately from the root pnpm workspace. If its workflow reports that no package exists, first verify that `.conversation/package.json` is present and restore the tracked app before debugging application code.

**Why:** The imported app directory can be absent from the working tree after workspace state changes, which produces a misleading pnpm error and makes the workflow look like an editor regression.

**How to apply:** Check `.conversation/package.json`, restore the tracked directory if needed, install its lockfile dependencies, then restart only the existing PERFI-SITE workflow.