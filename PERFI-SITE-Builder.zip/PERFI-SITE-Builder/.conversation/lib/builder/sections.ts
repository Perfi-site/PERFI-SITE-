import type { SectionType } from './types'

/**
 * Section registry: the single source of truth for every block type.
 *
 * `defaults()` produces the canonical props shape for a new block, and
 * `fields` describes how to edit those props. The visual editor renders the
 * right-hand edit panel entirely from `fields`, so adding a new editable
 * property never requires touching the editor UI.
 */

export type FieldKind =
  | 'text'
  | 'textarea'
  | 'image'
  | 'select'
  | 'list'
  | 'stringlist'

export type Field = {
  key: string
  label: string
  kind: FieldKind
  options?: { label: string; value: string }[]
  /** For `list` fields: the editable fields of each item. */
  itemFields?: Field[]
  /** For `list` fields: which item key to use as the row label. */
  itemLabelKey?: string
  placeholder?: string
}

export type SectionDescriptor = {
  type: SectionType
  label: string
  /** lucide-react icon name, resolved to a component in the editor UI. */
  icon: string
  description: string
  defaults: () => Record<string, unknown>
  fields: Field[]
}

const alignField: Field = {
  key: 'align',
  label: 'Alignment',
  kind: 'select',
  options: [
    { label: 'Left', value: 'left' },
    { label: 'Center', value: 'center' },
    { label: 'Right', value: 'right' },
  ],
}

function img(query: string, w = 800, h = 600) {
  return `/placeholder.svg?height=${h}&width=${w}&query=${encodeURIComponent(query)}`
}

export const SECTION_REGISTRY: Record<SectionType, SectionDescriptor> = {
  navigation: {
    type: 'navigation',
    label: 'Navigation',
    icon: 'Navigation',
    description: 'Top menu bar with brand and links.',
    defaults: () => ({
      brand: 'Your Brand',
      links: [
        { label: 'Home', href: '#' },
        { label: 'About', href: '#about' },
        { label: 'Services', href: '#services' },
        { label: 'Contact', href: '#contact' },
      ],
      ctaLabel: 'Get Started',
      ctaHref: '#',
    }),
    fields: [
      { key: 'brand', label: 'Brand name', kind: 'text' },
      {
        key: 'links',
        label: 'Menu links',
        kind: 'list',
        itemLabelKey: 'label',
        itemFields: [
          { key: 'label', label: 'Label', kind: 'text' },
          { key: 'href', label: 'Link', kind: 'text' },
        ],
      },
      { key: 'ctaLabel', label: 'Button label', kind: 'text' },
      { key: 'ctaHref', label: 'Button link', kind: 'text' },
    ],
  },
  hero: {
    type: 'hero',
    label: 'Hero',
    icon: 'Megaphone',
    description: 'Large intro banner with headline and call to action.',
    defaults: () => ({
      heading: 'A headline that sells your idea',
      subheading:
        'A short, compelling description of what you offer and why it matters to your visitors.',
      ctaLabel: 'Get Started',
      ctaHref: '#',
      secondaryLabel: 'Learn More',
      secondaryHref: '#about',
      image: img('modern product hero image', 1000, 700),
      align: 'left',
    }),
    fields: [
      { key: 'heading', label: 'Heading', kind: 'text' },
      { key: 'subheading', label: 'Subheading', kind: 'textarea' },
      { key: 'ctaLabel', label: 'Primary button', kind: 'text' },
      { key: 'ctaHref', label: 'Primary link', kind: 'text' },
      { key: 'secondaryLabel', label: 'Secondary button', kind: 'text' },
      { key: 'secondaryHref', label: 'Secondary link', kind: 'text' },
      { key: 'image', label: 'Image', kind: 'image' },
      alignField,
    ],
  },
  about: {
    type: 'about',
    label: 'About',
    icon: 'Info',
    description: 'A story section with an image and supporting copy.',
    defaults: () => ({
      heading: 'Built around your customers',
      body: 'Tell visitors who you are, what you believe, and why your work matters. Keep the story personal, clear, and focused on the people you serve.',
      image: img('business team collaborating', 900, 650),
      imageAlt: 'Our team collaborating',
      align: 'left',
    }),
    fields: [
      { key: 'heading', label: 'Heading', kind: 'text' },
      { key: 'body', label: 'Body text', kind: 'textarea' },
      { key: 'image', label: 'Image', kind: 'image' },
      { key: 'imageAlt', label: 'Image alt text', kind: 'text' },
      alignField,
    ],
  },
  services: {
    type: 'services',
    label: 'Services',
    icon: 'BriefcaseBusiness',
    description: 'A clear list of services and what each one delivers.',
    defaults: () => ({
      heading: 'How we can help',
      subheading: 'Practical services designed around your goals.',
      items: [
        { title: 'Strategy', description: 'A focused plan that turns your next goal into clear action.' },
        { title: 'Design', description: 'Thoughtful experiences that make your brand easier to choose.' },
        { title: 'Delivery', description: 'Reliable execution with momentum from start to finish.' },
      ],
    }),
    fields: [
      { key: 'heading', label: 'Heading', kind: 'text' },
      { key: 'subheading', label: 'Subheading', kind: 'textarea' },
      { key: 'items', label: 'Services', kind: 'list', itemLabelKey: 'title', itemFields: [
        { key: 'title', label: 'Service name', kind: 'text' },
        { key: 'description', label: 'Description', kind: 'textarea' },
      ] },
    ],
  },
  products: {
    type: 'products',
    label: 'Products',
    icon: 'Package',
    description: 'A product grid with images, descriptions, and links.',
    defaults: () => ({
      heading: 'Featured products',
      items: [
        { name: 'Signature product', description: 'A short product description that explains the value.', price: '$49', image: img('premium product', 700, 520), href: '#' },
        { name: 'Everyday essential', description: 'A practical choice for customers who want more.', price: '$29', image: img('minimal product', 700, 520), href: '#' },
        { name: 'Custom option', description: 'A flexible solution made to fit your needs.', price: 'From $79', image: img('custom product', 700, 520), href: '#' },
      ],
    }),
    fields: [
      { key: 'heading', label: 'Heading', kind: 'text' },
      { key: 'items', label: 'Products', kind: 'list', itemLabelKey: 'name', itemFields: [
        { key: 'name', label: 'Product name', kind: 'text' },
        { key: 'description', label: 'Description', kind: 'textarea' },
        { key: 'price', label: 'Price', kind: 'text' },
        { key: 'image', label: 'Image', kind: 'image' },
        { key: 'href', label: 'Product link', kind: 'text' },
      ] },
    ],
  },
  team: {
    type: 'team',
    label: 'Team',
    icon: 'Users',
    description: 'Introduce the people behind your business.',
    defaults: () => ({
      heading: 'Meet the team',
      items: [
        { name: 'Avery Morgan', role: 'Founder & Director', bio: 'A short introduction to this team member.', image: img('professional portrait one', 500, 500) },
        { name: 'Jordan Lee', role: 'Creative Lead', bio: 'A short introduction to this team member.', image: img('professional portrait two', 500, 500) },
        { name: 'Taylor Smith', role: 'Client Partner', bio: 'A short introduction to this team member.', image: img('professional portrait three', 500, 500) },
      ],
    }),
    fields: [
      { key: 'heading', label: 'Heading', kind: 'text' },
      { key: 'items', label: 'Team members', kind: 'list', itemLabelKey: 'name', itemFields: [
        { key: 'name', label: 'Name', kind: 'text' },
        { key: 'role', label: 'Role', kind: 'text' },
        { key: 'bio', label: 'Bio', kind: 'textarea' },
        { key: 'image', label: 'Photo', kind: 'image' },
      ] },
    ],
  },
  faq: {
    type: 'faq',
    label: 'FAQ',
    icon: 'CircleHelp',
    description: 'Answer common customer questions before they ask.',
    defaults: () => ({
      heading: 'Frequently asked questions',
      items: [
        { question: 'How does it work?', answer: 'Explain the first step and what a customer can expect.' },
        { question: 'Who is this for?', answer: 'Describe the people or businesses who get the most value.' },
        { question: 'How do I get started?', answer: 'Tell visitors exactly what action to take next.' },
      ],
    }),
    fields: [
      { key: 'heading', label: 'Heading', kind: 'text' },
      { key: 'items', label: 'Questions', kind: 'list', itemLabelKey: 'question', itemFields: [
        { key: 'question', label: 'Question', kind: 'text' },
        { key: 'answer', label: 'Answer', kind: 'textarea' },
      ] },
    ],
  },
  cta: {
    type: 'cta',
    label: 'Call To Action',
    icon: 'Megaphone',
    description: 'A focused invitation to take the next step.',
    defaults: () => ({
      heading: 'Ready to take the next step?',
      body: 'Give visitors one clear reason to act now.',
      ctaLabel: 'Get started',
      ctaHref: '#contact',
      align: 'center',
    }),
    fields: [
      { key: 'heading', label: 'Heading', kind: 'text' },
      { key: 'body', label: 'Supporting text', kind: 'textarea' },
      { key: 'ctaLabel', label: 'Button label', kind: 'text' },
      { key: 'ctaHref', label: 'Button link', kind: 'text' },
      alignField,
    ],
  },
  heading: {
    type: 'heading',
    label: 'Heading',
    icon: 'Heading',
    description: 'A section title with optional subtitle.',
    defaults: () => ({
      text: 'Section heading',
      subtitle: 'Supporting text that introduces this section.',
      align: 'center',
    }),
    fields: [
      { key: 'text', label: 'Heading', kind: 'text' },
      { key: 'subtitle', label: 'Subtitle', kind: 'textarea' },
      alignField,
    ],
  },
  text: {
    type: 'text',
    label: 'Text',
    icon: 'Text',
    description: 'A rich paragraph of content.',
    defaults: () => ({
      body:
        'Write your content here. Share your story, describe your offering, or explain what makes your business different. Keep it clear and focused on your visitor.',
      align: 'left',
    }),
    fields: [
      { key: 'body', label: 'Body text', kind: 'textarea' },
      alignField,
    ],
  },
  image: {
    type: 'image',
    label: 'Image',
    icon: 'Image',
    description: 'A single image with optional caption.',
    defaults: () => ({
      src: img('feature image', 1000, 600),
      alt: 'Descriptive alt text',
      caption: '',
    }),
    fields: [
      { key: 'src', label: 'Image', kind: 'image' },
      { key: 'alt', label: 'Alt text', kind: 'text' },
      { key: 'caption', label: 'Caption', kind: 'text' },
    ],
  },
  video: {
    type: 'video',
    label: 'Video',
    icon: 'Video',
    description: 'Embed a YouTube or Vimeo video.',
    defaults: () => ({
      url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      title: 'Watch our story',
    }),
    fields: [
      { key: 'title', label: 'Title', kind: 'text' },
      { key: 'url', label: 'Video URL', kind: 'text', placeholder: 'YouTube or Vimeo link' },
    ],
  },
  button: {
    type: 'button',
    label: 'Button',
    icon: 'MousePointerClick',
    description: 'A standalone call-to-action button.',
    defaults: () => ({
      label: 'Click here',
      href: '#',
      style: 'primary',
      align: 'center',
    }),
    fields: [
      { key: 'label', label: 'Label', kind: 'text' },
      { key: 'href', label: 'Link', kind: 'text' },
      {
        key: 'style',
        label: 'Style',
        kind: 'select',
        options: [
          { label: 'Primary', value: 'primary' },
          { label: 'Accent', value: 'accent' },
          { label: 'Outline', value: 'outline' },
        ],
      },
      alignField,
    ],
  },
  form: {
    type: 'form',
    label: 'Form',
    icon: 'ClipboardList',
    description: 'A contact or signup form.',
    defaults: () => ({
      title: 'Get in touch',
      description: 'Fill out the form and we will get back to you shortly.',
      fields: [
        { label: 'Name', type: 'text' },
        { label: 'Email', type: 'email' },
        { label: 'Message', type: 'textarea' },
      ],
      submitLabel: 'Send message',
    }),
    fields: [
      { key: 'title', label: 'Title', kind: 'text' },
      { key: 'description', label: 'Description', kind: 'textarea' },
      {
        key: 'fields',
        label: 'Form fields',
        kind: 'list',
        itemLabelKey: 'label',
        itemFields: [
          { key: 'label', label: 'Label', kind: 'text' },
          {
            key: 'type',
            label: 'Type',
            kind: 'select',
            options: [
              { label: 'Text', value: 'text' },
              { label: 'Email', value: 'email' },
              { label: 'Phone', value: 'tel' },
              { label: 'Message', value: 'textarea' },
            ],
          },
        ],
      },
      { key: 'submitLabel', label: 'Submit button', kind: 'text' },
    ],
  },
  cards: {
    type: 'cards',
    label: 'Features',
    icon: 'LayoutGrid',
    description: 'A grid of features or benefits.',
    defaults: () => ({
      heading: 'What we offer',
      items: [
        { title: 'Feature one', description: 'A short description of this feature.' },
        { title: 'Feature two', description: 'A short description of this feature.' },
        { title: 'Feature three', description: 'A short description of this feature.' },
      ],
    }),
    fields: [
      { key: 'heading', label: 'Heading', kind: 'text' },
      {
        key: 'items',
        label: 'Cards',
        kind: 'list',
        itemLabelKey: 'title',
        itemFields: [
          { key: 'title', label: 'Title', kind: 'text' },
          { key: 'description', label: 'Description', kind: 'textarea' },
        ],
      },
    ],
  },
  testimonials: {
    type: 'testimonials',
    label: 'Testimonials',
    icon: 'Quote',
    description: 'Customer quotes and reviews.',
    defaults: () => ({
      heading: 'What our clients say',
      items: [
        { quote: 'This team exceeded our expectations.', author: 'Alex Morgan', role: 'CEO, Acme' },
        { quote: 'Professional, fast and reliable.', author: 'Sam Lee', role: 'Founder, Nova' },
      ],
    }),
    fields: [
      { key: 'heading', label: 'Heading', kind: 'text' },
      {
        key: 'items',
        label: 'Testimonials',
        kind: 'list',
        itemLabelKey: 'author',
        itemFields: [
          { key: 'quote', label: 'Quote', kind: 'textarea' },
          { key: 'author', label: 'Author', kind: 'text' },
          { key: 'role', label: 'Role', kind: 'text' },
        ],
      },
    ],
  },
  pricing: {
    type: 'pricing',
    label: 'Pricing Table',
    icon: 'CircleDollarSign',
    description: 'Plans and pricing tiers.',
    defaults: () => ({
      heading: 'Simple pricing',
      items: [
        {
          name: 'Basic',
          price: '$19',
          period: '/mo',
          features: ['Feature one', 'Feature two', 'Feature three'],
          ctaLabel: 'Choose Basic',
        },
        {
          name: 'Pro',
          price: '$49',
          period: '/mo',
          features: ['Everything in Basic', 'Feature four', 'Feature five'],
          ctaLabel: 'Choose Pro',
        },
      ],
    }),
    fields: [
      { key: 'heading', label: 'Heading', kind: 'text' },
      {
        key: 'items',
        label: 'Plans',
        kind: 'list',
        itemLabelKey: 'name',
        itemFields: [
          { key: 'name', label: 'Plan name', kind: 'text' },
          { key: 'price', label: 'Price', kind: 'text' },
          { key: 'period', label: 'Period', kind: 'text' },
          { key: 'features', label: 'Features', kind: 'stringlist' },
          { key: 'ctaLabel', label: 'Button label', kind: 'text' },
        ],
      },
    ],
  },
  gallery: {
    type: 'gallery',
    label: 'Gallery',
    icon: 'Images',
    description: 'A grid of images.',
    defaults: () => ({
      heading: 'Gallery',
      images: [
        { src: img('gallery photo one'), alt: 'Gallery image' },
        { src: img('gallery photo two'), alt: 'Gallery image' },
        { src: img('gallery photo three'), alt: 'Gallery image' },
      ],
    }),
    fields: [
      { key: 'heading', label: 'Heading', kind: 'text' },
      {
        key: 'images',
        label: 'Images',
        kind: 'list',
        itemLabelKey: 'alt',
        itemFields: [
          { key: 'src', label: 'Image', kind: 'image' },
          { key: 'alt', label: 'Alt text', kind: 'text' },
        ],
      },
    ],
  },
  contact: {
    type: 'contact',
    label: 'Contact Info',
    icon: 'Mail',
    description: 'Email, phone and address details.',
    defaults: () => ({
      heading: 'Contact us',
      email: 'hello@example.com',
      phone: '+1 (555) 000-0000',
      address: '123 Business Ave, Suite 100, City, Country',
    }),
    fields: [
      { key: 'heading', label: 'Heading', kind: 'text' },
      { key: 'email', label: 'Email', kind: 'text' },
      { key: 'phone', label: 'Phone', kind: 'text' },
      { key: 'address', label: 'Address', kind: 'textarea' },
    ],
  },
  social: {
    type: 'social',
    label: 'Social Links',
    icon: 'Share2',
    description: 'Links to your social profiles.',
    defaults: () => ({
      heading: 'Follow us',
      links: [
        { platform: 'Twitter', href: '#' },
        { platform: 'Instagram', href: '#' },
        { platform: 'LinkedIn', href: '#' },
      ],
    }),
    fields: [
      { key: 'heading', label: 'Heading', kind: 'text' },
      {
        key: 'links',
        label: 'Profiles',
        kind: 'list',
        itemLabelKey: 'platform',
        itemFields: [
          {
            key: 'platform',
            label: 'Platform',
            kind: 'select',
            options: [
              { label: 'Twitter', value: 'Twitter' },
              { label: 'Instagram', value: 'Instagram' },
              { label: 'LinkedIn', value: 'LinkedIn' },
              { label: 'Facebook', value: 'Facebook' },
              { label: 'YouTube', value: 'YouTube' },
              { label: 'GitHub', value: 'GitHub' },
            ],
          },
          { key: 'href', label: 'Link', kind: 'text' },
        ],
      },
    ],
  },
  footer: {
    type: 'footer',
    label: 'Footer',
    icon: 'PanelBottom',
    description: 'Closing bar with links and copyright.',
    defaults: () => ({
      brand: 'Your Brand',
      tagline: 'A short tagline for your business.',
      links: [
        { label: 'Privacy', href: '#' },
        { label: 'Terms', href: '#' },
      ],
      copyright: `© ${new Date().getFullYear()} Your Brand. All rights reserved.`,
    }),
    fields: [
      { key: 'brand', label: 'Brand name', kind: 'text' },
      { key: 'tagline', label: 'Tagline', kind: 'text' },
      {
        key: 'links',
        label: 'Footer links',
        kind: 'list',
        itemLabelKey: 'label',
        itemFields: [
          { key: 'label', label: 'Label', kind: 'text' },
          { key: 'href', label: 'Link', kind: 'text' },
        ],
      },
      { key: 'copyright', label: 'Copyright', kind: 'text' },
    ],
  },
}

/** Order sections appear in the "add section" menu. */
export const SECTION_ORDER: SectionType[] = [
  'navigation',
  'hero',
  'about',
  'services',
  'products',
  'team',
  'faq',
  'cta',
  'heading',
  'text',
  'image',
  'video',
  'button',
  'cards',
  'testimonials',
  'pricing',
  'gallery',
  'form',
  'contact',
  'social',
  'footer',
]
