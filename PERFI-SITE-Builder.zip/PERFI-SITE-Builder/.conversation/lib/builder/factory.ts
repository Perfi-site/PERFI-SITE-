import type { Page, Section, SectionType, Site, SiteBuildMode } from './types'
import { SECTION_REGISTRY } from './sections'
import { DEFAULT_THEME } from './theme'

export function uid(prefix = 'id'): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return `${prefix}_${crypto.randomUUID().slice(0, 8)}`
  }
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`
}

export function createSection(type: SectionType, props?: Record<string, unknown>): Section {
  return {
    id: uid('sec'),
    type,
    props: props ?? SECTION_REGISTRY[type].defaults(),
  }
}

export function createPage(name: string, sections: Section[] = []): Page {
  return {
    id: uid('page'),
    name,
    slug: slugify(name),
    sections,
  }
}

export function slugify(value: string): string {
  return (
    value
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'page'
  )
}

/** Standard page skeleton used by manual templates and as an AI fallback shell. */
function standardPages(): Page[] {
  return [
    createPage('Home', [
      createSection('navigation'),
      createSection('hero'),
      createSection('cards'),
      createSection('testimonials'),
      createSection('footer'),
    ]),
    createPage('About', [
      createSection('navigation'),
      createSection('heading', {
        text: 'About us',
        subtitle: 'Learn more about our story and mission.',
        align: 'center',
      }),
      createSection('text'),
      createSection('footer'),
    ]),
    createPage('Services', [
      createSection('navigation'),
      createSection('heading', {
        text: 'Our services',
        subtitle: 'Everything we offer to help you grow.',
        align: 'center',
      }),
      createSection('cards'),
      createSection('pricing'),
      createSection('footer'),
    ]),
    createPage('Contact', [
      createSection('navigation'),
      createSection('heading', {
        text: 'Contact us',
        subtitle: 'We would love to hear from you.',
        align: 'center',
      }),
      createSection('contact'),
      createSection('form'),
      createSection('footer'),
    ]),
  ]
}

export type ManualTemplate = 'blank' | 'business' | 'portfolio'

function templatePages(template: ManualTemplate): Page[] {
  if (template === 'blank') {
    return [createPage('Home', [createSection('navigation'), createSection('hero'), createSection('footer')])]
  }
  if (template === 'portfolio') {
    return [
      createPage('Home', [
        createSection('navigation'),
        createSection('hero'),
        createSection('about'),
        createSection('gallery'),
        createSection('testimonials'),
        createSection('footer'),
      ]),
      createPage('Contact', [
        createSection('navigation'),
        createSection('heading', { text: 'Get in touch', subtitle: '', align: 'center' }),
        createSection('contact'),
        createSection('footer'),
      ]),
    ]
  }
  return standardPages()
}

export function createSite(params: {
  name: string
  buildMode: SiteBuildMode
  pages?: Page[]
  template?: ManualTemplate
  aiPrompt?: string
}): Site {
  const now = new Date().toISOString()
  const pages = params.pages ?? templatePages(params.template ?? 'business')
  return {
    id: uid('site'),
    name: params.name,
    buildMode: params.buildMode,
    status: 'draft',
    theme: { ...DEFAULT_THEME },
    pages,
    domain: null,
    subdomain: `${slugify(params.name)}.perfi-site.com`,
    subscriptionStatus: 'none',
    aiPrompt: params.aiPrompt,
    createdAt: now,
    updatedAt: now,
    publishedAt: null,
    trialEndsAt: null,
  }
}

export { standardPages }
