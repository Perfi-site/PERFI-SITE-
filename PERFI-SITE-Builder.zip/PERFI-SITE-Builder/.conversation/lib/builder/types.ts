/**
 * PERFI-SITE Website Builder domain model.
 *
 * A Site is a tree: Site -> Pages -> Sections. Sections are typed content
 * blocks with a canonical `props` shape per type (see lib/builder/sections.tsx).
 *
 * These types are the contract the visual editor, AI generator and future
 * Supabase persistence layer all build against. Nothing here performs live
 * hosting, domain registration or payments — those connect in later stages.
 */

export type SectionType =
  | 'navigation'
  | 'hero'
  | 'about'
  | 'services'
  | 'products'
  | 'team'
  | 'faq'
  | 'cta'
  | 'heading'
  | 'text'
  | 'image'
  | 'video'
  | 'button'
  | 'form'
  | 'cards'
  | 'testimonials'
  | 'pricing'
  | 'gallery'
  | 'contact'
  | 'social'
  | 'footer'

/** A single content block on a page. `props` follows the per-type shape. */
export type Section = {
  id: string
  type: SectionType
  props: Record<string, unknown>
}

export type Page = {
  id: string
  name: string
  slug: string
  sections: Section[]
}

export type SiteTheme = {
  primary: string
  accent: string
  background: string
  foreground: string
  fontHeading: string
  fontBody: string
  radius: number
  buttonStyle: 'solid' | 'soft' | 'pill'
  spacing: 'compact' | 'comfortable' | 'spacious'
}

export type SiteStatus = 'draft' | 'published' | 'suspended' | 'archived'
export type SiteBuildMode = 'ai' | 'manual'

/** Subscription state shown on the My Websites dashboard. Real billing later. */
export type SiteSubscriptionStatus = 'none' | 'trialing' | 'active' | 'past_due'

export type Site = {
  id: string
  name: string
  buildMode: SiteBuildMode
  status: SiteStatus
  theme: SiteTheme
  pages: Page[]
  /** Connected custom domain, or null while on a PERFI-SITE subdomain. */
  domain: string | null
  subdomain: string
  subscriptionStatus: SiteSubscriptionStatus
  aiPrompt?: string
  createdAt: string
  updatedAt: string
  /** Set the first time a site is published. Drives the 7-day free trial. */
  publishedAt: string | null
  trialEndsAt: string | null
}

export const TRIAL_DAYS = 7

/** Days left in the free trial, or null when there is no active trial. */
export function trialDaysRemaining(site: Pick<Site, 'trialEndsAt'>): number | null {
  if (!site.trialEndsAt) return null
  const ms = new Date(site.trialEndsAt).getTime() - Date.now()
  if (ms <= 0) return 0
  return Math.ceil(ms / (1000 * 60 * 60 * 24))
}
