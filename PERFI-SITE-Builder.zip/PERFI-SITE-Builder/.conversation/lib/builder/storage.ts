import { createSite, uid } from './factory'
import type { ManualTemplate } from './factory'
import { TRIAL_DAYS, type Site } from './types'

export const DRAFT_STORAGE_KEY = 'perfi-site:draft'
export const SITES_STORAGE_KEY = 'perfi-site:sites'
export const TRIAL_STORAGE_KEY = 'perfi-site:account-trial'

export type TrialRecord = {
  startedAt: string
  endsAt: string
}

export type TrialStatus = {
  state: 'not_started' | 'active' | 'expired'
  startedAt: string | null
  endsAt: string | null
  daysRemaining: number
}

export type CreateSiteInput = {
  name: string
  template?: ManualTemplate
  buildMode?: Site['buildMode']
}

export type SiteRepository = {
  listSites(): Site[]
  getSite(siteId: string): Site | null
  createSite(input: CreateSiteInput): Site
  updateSite(site: Site): Site
  duplicateSite(siteId: string): Site | null
  archiveSite(siteId: string): Site | null
  restoreSite(siteId: string): Site | null
  publishSite(siteId: string): Site | null
  unpublishSite(siteId: string): Site | null
  getTrialStatus(): TrialStatus
}

function isBrowser() {
  return typeof window !== 'undefined'
}

export function loadDraft(): Site | null {
  if (!isBrowser()) return null
  try {
    const raw = window.localStorage.getItem(DRAFT_STORAGE_KEY)
    return raw ? (JSON.parse(raw) as Site) : null
  } catch {
    return null
  }
}

export function loadSites(): Site[] {
  if (!isBrowser()) return []
  try {
    const raw = window.localStorage.getItem(SITES_STORAGE_KEY)
    const sites = raw ? (JSON.parse(raw) as Site[]) : []
    return Array.isArray(sites) ? sites : []
  } catch {
    return []
  }
}

export function saveSite(site: Site) {
  if (!isBrowser()) return site
  const current = loadSites().filter((item) => item.id !== site.id)
  window.localStorage.setItem(DRAFT_STORAGE_KEY, JSON.stringify(site))
  window.localStorage.setItem(SITES_STORAGE_KEY, JSON.stringify([site, ...current]))
  return site
}

function writeSites(sites: Site[]) {
  if (!isBrowser()) return
  window.localStorage.setItem(SITES_STORAGE_KEY, JSON.stringify(sites))
}

function writeTrial(record: TrialRecord) {
  if (!isBrowser()) return
  window.localStorage.setItem(TRIAL_STORAGE_KEY, JSON.stringify(record))
}

export function getTrialRecord(): TrialRecord | null {
  if (!isBrowser()) return null
  try {
    const raw = window.localStorage.getItem(TRIAL_STORAGE_KEY)
    if (raw) return JSON.parse(raw) as TrialRecord

    // Migrate sites created by the first local builder pass, which stored
    // trial dates on the site but did not yet have an account-level record.
    const legacyPublishedSite = loadSites()
      .filter((site) => site.publishedAt && site.trialEndsAt)
      .sort((a, b) => new Date(a.publishedAt ?? 0).getTime() - new Date(b.publishedAt ?? 0).getTime())[0]
    if (!legacyPublishedSite?.publishedAt || !legacyPublishedSite.trialEndsAt) return null
    const migrated = { startedAt: legacyPublishedSite.publishedAt, endsAt: legacyPublishedSite.trialEndsAt }
    writeTrial(migrated)
    return migrated
  } catch {
    return null
  }
}

export function getTrialStatus(): TrialStatus {
  const trial = getTrialRecord()
  if (!trial) return { state: 'not_started', startedAt: null, endsAt: null, daysRemaining: 0 }
  const remainingMs = new Date(trial.endsAt).getTime() - Date.now()
  return {
    state: remainingMs > 0 ? 'active' : 'expired',
    startedAt: trial.startedAt,
    endsAt: trial.endsAt,
    daysRemaining: remainingMs > 0 ? Math.ceil(remainingMs / (1000 * 60 * 60 * 24)) : 0,
  }
}

export function getSite(siteId: string): Site | null {
  return loadSites().find((site) => site.id === siteId) ?? null
}

export function createStoredSite(input: CreateSiteInput): Site {
  const site = createSite({
    name: input.name,
    buildMode: input.buildMode ?? 'manual',
    template: input.template ?? 'business',
  })
  saveSite(site)
  return site
}

function cloneSite(source: Site): Site {
  const copy = JSON.parse(JSON.stringify(source)) as Site
  const siteId = uid('site')
  copy.id = siteId
  copy.name = `${source.name} copy`
  copy.subdomain = `${source.subdomain.replace(/\.perfi-site\.com$/, '')}-copy.perfi-site.com`
  copy.status = 'draft'
  copy.subscriptionStatus = 'none'
  copy.publishedAt = null
  copy.trialEndsAt = null
  copy.createdAt = new Date().toISOString()
  copy.updatedAt = copy.createdAt
  copy.pages = copy.pages.map((page) => {
    const nextPageId = uid('page')
    return {
      ...page,
      id: nextPageId,
      slug: `${page.slug}-copy`,
      sections: page.sections.map((section) => ({ ...section, id: uid('sec') })),
    }
  })
  return copy
}

export function duplicateStoredSite(siteId: string): Site | null {
  const source = getSite(siteId)
  if (!source) return null
  const duplicate = cloneSite(source)
  saveSite(duplicate)
  return duplicate
}

export function archiveStoredSite(siteId: string): Site | null {
  const site = getSite(siteId)
  if (!site) return null
  const archived = { ...site, status: 'archived' as const, updatedAt: new Date().toISOString() }
  saveSite(archived)
  return archived
}

export function restoreStoredSite(siteId: string): Site | null {
  const site = getSite(siteId)
  if (!site) return null
  const restored = { ...site, status: 'draft' as const, updatedAt: new Date().toISOString() }
  saveSite(restored)
  return restored
}

export function publishStoredSite(siteId: string): Site | null {
  const site = getSite(siteId)
  if (!site) return null

  const now = new Date().toISOString()
  let trial = getTrialRecord()
  if (!trial) {
    trial = {
      startedAt: now,
      endsAt: new Date(Date.now() + TRIAL_DAYS * 24 * 60 * 60 * 1000).toISOString(),
    }
    writeTrial(trial)
  }

  const trialActive = new Date(trial.endsAt).getTime() > Date.now()
  const published = {
    ...site,
    status: 'published' as const,
    subscriptionStatus: trialActive ? 'trialing' as const : 'none' as const,
    publishedAt: site.publishedAt ?? now,
    trialEndsAt: trial.endsAt,
    updatedAt: now,
  }
  saveSite(published)
  return published
}

export function unpublishStoredSite(siteId: string): Site | null {
  const site = getSite(siteId)
  if (!site) return null
  const trial = getTrialStatus()
  const unpublished = {
    ...site,
    status: 'draft' as const,
    subscriptionStatus: trial.state === 'active' ? 'trialing' as const : 'none' as const,
    updatedAt: new Date().toISOString(),
  }
  saveSite(unpublished)
  return unpublished
}

export const localSiteRepository: SiteRepository = {
  listSites: loadSites,
  getSite,
  createSite: createStoredSite,
  updateSite: saveSite,
  duplicateSite: duplicateStoredSite,
  archiveSite: archiveStoredSite,
  restoreSite: restoreStoredSite,
  publishSite: publishStoredSite,
  unpublishSite: unpublishStoredSite,
  getTrialStatus,
}

export function clearDraft() {
  if (!isBrowser()) return
  window.localStorage.removeItem(DRAFT_STORAGE_KEY)
}