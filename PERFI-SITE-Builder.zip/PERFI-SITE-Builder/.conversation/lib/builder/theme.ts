import type { SiteTheme } from './types'

/** Curated font stacks offered in the builder. Values are ready-to-use CSS. */
export const FONT_OPTIONS: { label: string; value: string }[] = [
  { label: 'Space Grotesk', value: "'Space Grotesk', ui-sans-serif, system-ui, sans-serif" },
  { label: 'Inter', value: "'Inter', ui-sans-serif, system-ui, sans-serif" },
  { label: 'Georgia (Serif)', value: "Georgia, 'Times New Roman', serif" },
  { label: 'System Sans', value: "ui-sans-serif, system-ui, -apple-system, sans-serif" },
  { label: 'Trebuchet', value: "'Trebuchet MS', 'Segoe UI', sans-serif" },
  { label: 'Courier (Mono)', value: "'Courier New', ui-monospace, monospace" },
]

/** Preset palettes users can start from. First entry is the PERFI-SITE brand. */
export const THEME_PRESETS: { name: string; primary: string; accent: string }[] = [
  { name: 'PERFI Blue & Gold', primary: '#1e40af', accent: '#d4a017' },
  { name: 'Midnight', primary: '#0f172a', accent: '#38bdf8' },
  { name: 'Forest', primary: '#166534', accent: '#f59e0b' },
  { name: 'Rose', primary: '#be123c', accent: '#f472b6' },
  { name: 'Violet', primary: '#6d28d9', accent: '#22d3ee' },
  { name: 'Slate', primary: '#334155', accent: '#f97316' },
]

export const DEFAULT_THEME: SiteTheme = {
  primary: '#1e40af',
  accent: '#d4a017',
  background: '#ffffff',
  foreground: '#0f172a',
  fontHeading: "'Space Grotesk', ui-sans-serif, system-ui, sans-serif",
  fontBody: "'Inter', ui-sans-serif, system-ui, sans-serif",
  radius: 12,
  buttonStyle: 'solid',
  spacing: 'comfortable',
}

/** Map an abstract AI "font style" to a concrete heading/body pairing. */
export function fontStyleToPair(style: string): { fontHeading: string; fontBody: string } {
  switch (style) {
    case 'classic':
    case 'elegant':
      return { fontHeading: FONT_OPTIONS[2].value, fontBody: FONT_OPTIONS[2].value }
    case 'playful':
      return { fontHeading: FONT_OPTIONS[4].value, fontBody: FONT_OPTIONS[1].value }
    case 'modern':
    default:
      return { fontHeading: FONT_OPTIONS[0].value, fontBody: FONT_OPTIONS[1].value }
  }
}

/** CSS custom properties applied to a preview/publish container. */
export function themeToCssVars(theme: SiteTheme): React.CSSProperties {
  return {
    // @ts-expect-error -- CSS custom properties
    '--site-primary': theme.primary,
    '--site-accent': theme.accent,
    '--site-bg': theme.background,
    '--site-fg': theme.foreground,
    '--site-radius': `${theme.radius}px`,
    '--site-font-heading': theme.fontHeading,
    '--site-font-body': theme.fontBody,
    '--site-button-radius': theme.buttonStyle === 'pill'
      ? '999px'
      : theme.buttonStyle === 'soft'
        ? `${Math.max(theme.radius, 16)}px`
        : `${Math.max(theme.radius / 2, 4)}px`,
    '--site-section-spacing': theme.spacing === 'compact'
      ? '2rem'
      : theme.spacing === 'spacious'
        ? '5.5rem'
        : '3.5rem',
    backgroundColor: theme.background,
    color: theme.foreground,
    fontFamily: theme.fontBody,
  }
}
