import { pricingPlans, type PricingPlan } from '@/lib/config'
import type { Subscription, SubscriptionInterval } from '@/lib/types'

/**
 * Billing remains a service boundary. The catalog is available now, while
 * checkout and subscription reads stay explicitly unconfigured until a real
 * provider is connected.
 */
export const PLAN_SELECTION_STORAGE_KEY = 'perfi-site:plan-selection'

export type PlanSelection = {
  planId: PricingPlan['id']
  interval: SubscriptionInterval
}

export type CheckoutRequest = PlanSelection & {
  userId?: string
}

export type BillingService = {
  getPlans(): PricingPlan[]
  getSubscription(userId: string): Promise<Subscription | null>
  createCheckout(request: CheckoutRequest): Promise<never>
}

export const billingService: BillingService = {
  getPlans: () => pricingPlans,
  async getSubscription() {
    return null
  },
  async createCheckout() {
    throw new Error('Payment checkout is not connected yet.')
  },
}