/**
 * Central PERFI-SITE configuration.
 *
 * This is the single source of truth for brand, navigation and catalog data.
 * As backend stages land (Supabase, auth, payments, domains, hosting, AI builder,
 * services marketplace), the static arrays below are replaced by data-access
 * functions that read from the database — the page components stay unchanged.
 */

export const company = {
  legalName: 'PERFI TECH GLOBAL VENTURE LIMITED',
  product: 'PERFI-SITE',
  tagline: 'INNOVATE | INVEST | BUILD | GROW | GLOBAL',
  email: 'hello@perfi-site.com',
  supportEmail: 'support@perfi-site.com',
} as const

export const primaryNav = [
  { label: 'Home', href: '/' },
  { label: 'About', href: '/about' },
  { label: 'Services', href: '/services' },
  { label: 'Products', href: '/products' },
  { label: 'Pricing', href: '/pricing' },
  { label: 'Contact', href: '/contact' },
] as const

export const footerNav = [
  {
    title: 'Platform',
    links: [
      { label: 'AI Website Builder', href: '/products#ai-builder' },
      { label: 'Manual Builder', href: '/products#manual-builder' },
      { label: 'Hosting', href: '/products#hosting' },
      { label: 'Domains', href: '/products#domains' },
      { label: 'E-commerce', href: '/products#ecommerce' },
    ],
  },
  {
    title: 'Company',
    links: [
      { label: 'About', href: '/about' },
      { label: 'Services', href: '/services' },
      { label: 'Pricing', href: '/pricing' },
      { label: 'Contact', href: '/contact' },
    ],
  },
  {
    title: 'Account',
    links: [
      { label: 'Log In', href: '/login' },
      { label: 'Sign Up', href: '/signup' },
      { label: 'Customer Dashboard', href: '/dashboard' },
      { label: 'Support', href: '/contact' },
    ],
  },
] as const

/** Homepage primary calls to action. Each maps to a future product flow. */
export const heroActions = [
  { label: 'Build with AI', href: '/dashboard/builder/ai', variant: 'primary' as const },
  { label: 'Build Manually', href: '/dashboard/builder/manual', variant: 'gold' as const },
  { label: 'Order PERFI TECH Services', href: '/services', variant: 'outline' as const },
  { label: 'Search Domain', href: '/dashboard/domains', variant: 'outline' as const },
] as const

export type PricingPlan = {
  id: string
  name: string
  description: string
  monthly: number
  annual: number
  featured?: boolean
  features: string[]
  cta: string
}

export const pricingPlans: PricingPlan[] = [
  {
    id: 'starter',
    name: 'Starter',
    description: 'Get your business online with the essentials.',
    monthly: 5,
    annual: 50,
    features: [
      '1 website',
      'AI + manual builder',
      'PERFI-SITE subdomain',
      '10 GB hosting',
      'Free SSL',
      'Email support',
    ],
    cta: 'Start building',
  },
  {
    id: 'business',
    name: 'Business',
    description: 'For businesses ready for more room to grow.',
    monthly: 10,
    annual: 100,
    featured: true,
    features: [
      '3 websites',
      'AI + manual builder',
      '100 GB hosting',
      'Website analytics',
      'Priority support',
    ],
    cta: 'Choose Business',
  },
  {
    id: 'professional',
    name: 'Professional',
    description: 'For established brands building a bigger presence.',
    monthly: 20,
    annual: 200,
    features: [
      '10 websites',
      'Unlimited hosting bandwidth',
      'Advanced analytics',
      'Priority PERFI TECH support',
      'Custom domain connection',
    ],
    cta: 'Choose Professional',
  },
]

export type Product = {
  id: string
  name: string
  tagline: string
  description: string
  icon: string
}

export const products: Product[] = [
  {
    id: 'ai-builder',
    name: 'AI Website Builder',
    tagline: 'Describe it. Launch it.',
    description:
      'Generate a complete, on-brand website from a single prompt, then refine visually.',
    icon: 'Sparkles',
  },
  {
    id: 'manual-builder',
    name: 'Manual Builder',
    tagline: 'Full creative control.',
    description:
      'A drag-and-drop editor with sections, themes and components for pixel-level control.',
    icon: 'LayoutTemplate',
  },
  {
    id: 'hosting',
    name: 'Hosting & Publishing',
    tagline: 'Fast, secure, global.',
    description:
      'One-click publishing to a global edge network with free SSL and automatic backups.',
    icon: 'Server',
  },
  {
    id: 'domains',
    name: 'Domain Search & Management',
    tagline: 'Claim your name.',
    description:
      'Search, register and manage domains with DNS controls and auto-renewal.',
    icon: 'Globe',
  },
  {
    id: 'ecommerce',
    name: 'E-commerce',
    tagline: 'Sell anywhere.',
    description:
      'Product catalogs, carts, checkout and order management built for global selling.',
    icon: 'ShoppingCart',
  },
  {
    id: 'analytics',
    name: 'Website Analytics',
    tagline: 'Know what works.',
    description:
      'Real-time traffic, conversion and audience insights for every site you publish.',
    icon: 'BarChart3',
  },
]

export type Service = {
  id: string
  name: string
  description: string
  startingPrice: number
  icon: string
}

/** PERFI TECH professional services available to order from the marketplace. */
export const services: Service[] = [
  {
    id: 'brand-identity',
    name: 'Brand Identity & Logo',
    description: 'Complete visual identity: logo, colors, typography and brand guidelines.',
    startingPrice: 350,
    icon: 'Palette',
  },
  {
    id: 'custom-development',
    name: 'Custom Web Development',
    description: 'Bespoke features, integrations and web apps built by PERFI TECH engineers.',
    startingPrice: 900,
    icon: 'Code2',
  },
  {
    id: 'seo-growth',
    name: 'SEO & Growth Marketing',
    description: 'Technical SEO, content strategy and campaigns to grow qualified traffic.',
    startingPrice: 450,
    icon: 'TrendingUp',
  },
  {
    id: 'store-setup',
    name: 'E-commerce Store Setup',
    description: 'Full storefront configuration, catalog import and payment readiness.',
    startingPrice: 600,
    icon: 'Store',
  },
  {
    id: 'migration',
    name: 'Website Migration',
    description: 'Move your existing site to PERFI-SITE with zero downtime.',
    startingPrice: 300,
    icon: 'MoveRight',
  },
  {
    id: 'consulting',
    name: 'Technology Consulting',
    description: 'Strategic advisory on architecture, scaling and digital transformation.',
    startingPrice: 500,
    icon: 'Lightbulb',
  },
]
