/**
 * PERFI-SITE domain model.
 *
 * These types describe the entities the platform will persist once the backend
 * stages are added (Supabase Postgres + Auth). They intentionally live in one
 * place so UI, server actions and future database schemas stay aligned.
 *
 * NOTE: No live payment, domain-registration or hosting logic exists yet.
 * These are contracts to build against, not implementations.
 */

export type UserRole = 'customer' | 'admin'

export type User = {
  id: string
  email: string
  fullName: string
  role: UserRole
  createdAt: string
}

export type SubscriptionInterval = 'monthly' | 'annual'
export type SubscriptionStatus = 'active' | 'trialing' | 'past_due' | 'canceled'

export type Subscription = {
  id: string
  userId: string
  planId: string
  interval: SubscriptionInterval
  status: SubscriptionStatus
  currentPeriodEnd: string
}

export type SiteStatus = 'draft' | 'published' | 'suspended'
export type SiteBuildMode = 'ai' | 'manual'

export type Site = {
  id: string
  userId: string
  name: string
  buildMode: SiteBuildMode
  status: SiteStatus
  domain: string | null
  updatedAt: string
}

export type DomainStatus = 'available' | 'registered' | 'transferring' | 'expired'

export type Domain = {
  id: string
  userId: string
  name: string
  status: DomainStatus
  autoRenew: boolean
  expiresAt: string | null
}

export type OrderStatus = 'pending' | 'in_progress' | 'delivered' | 'canceled'

export type ServiceOrder = {
  id: string
  userId: string
  serviceId: string
  status: OrderStatus
  amount: number
  createdAt: string
}

export type InvoiceStatus = 'draft' | 'open' | 'paid' | 'void'

export type Invoice = {
  id: string
  userId: string
  number: string
  amount: number
  status: InvoiceStatus
  issuedAt: string
  dueAt: string
}

export type SupportTicketStatus = 'open' | 'pending' | 'resolved'

export type SupportTicket = {
  id: string
  userId: string
  subject: string
  status: SupportTicketStatus
  updatedAt: string
}
