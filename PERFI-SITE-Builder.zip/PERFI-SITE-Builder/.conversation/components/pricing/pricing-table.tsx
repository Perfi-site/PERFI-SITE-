'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Check } from 'lucide-react'
import { cn } from '@/lib/utils'
import { buttonVariants } from '@/components/ui/button'
import { billingService } from '@/lib/billing/service'

export function PricingTable() {
  const [interval, setInterval] = useState<'monthly' | 'annual'>('monthly')
  const pricingPlans = billingService.getPlans()

  return (
    <div>
      <div className="mx-auto mb-10 flex w-fit items-center gap-1 rounded-full border border-border bg-card p-1">
        {(['monthly', 'annual'] as const).map((value) => (
          <button
            key={value}
            type="button"
            onClick={() => setInterval(value)}
            className={cn(
              'rounded-full px-4 py-1.5 text-sm font-medium capitalize transition-colors',
              interval === value
                ? 'bg-primary text-primary-foreground'
                : 'text-muted-foreground hover:text-foreground',
            )}
          >
            {value === 'annual' ? 'yearly' : value}
            {value === 'annual' && (
              <span className="ml-1.5 text-xs text-brand-gold">save 2 months</span>
            )}
          </button>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {pricingPlans.map((plan) => {
          const price = interval === 'monthly' ? plan.monthly : plan.annual
          const annualSavings = plan.monthly * 12 - plan.annual
          return (
            <div
              key={plan.id}
              className={cn(
                'relative flex flex-col rounded-2xl border bg-card p-8',
                plan.featured
                  ? 'border-primary shadow-xl shadow-primary/10 lg:-translate-y-2'
                  : 'border-border',
              )}
            >
              {plan.featured && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-brand-gold px-3 py-1 text-xs font-semibold text-[oklch(0.28_0.09_80)]">
                  Most popular
                </span>
              )}
              <h3 className="text-xl font-semibold">{plan.name}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{plan.description}</p>
              <div className="mt-6 flex items-baseline gap-1">
                <span className="font-display text-4xl font-bold">${price}</span>
                <span className="text-sm text-muted-foreground">
                  /{interval === 'monthly' ? 'mo' : 'yr'}
                </span>
              </div>
              <p className="mt-2 text-xs text-muted-foreground">
                {interval === 'monthly'
                  ? `or $${plan.annual}/year`
                  : `Save $${annualSavings}/year · $${(plan.annual / 12).toFixed(2)}/month equivalent`}
              </p>

              <Link
                href={`/signup?plan=${encodeURIComponent(plan.id)}&interval=${interval}`}
                className={cn(
                  buttonVariants({ size: 'lg', variant: plan.featured ? 'default' : 'outline' }),
                  'mt-6 h-11 w-full justify-center',
                )}
              >
                {plan.cta}
              </Link>

              <ul className="mt-8 space-y-3">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2.5 text-sm">
                    <Check className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
                    <span className="text-muted-foreground">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          )
        })}
      </div>
    </div>
  )
}
