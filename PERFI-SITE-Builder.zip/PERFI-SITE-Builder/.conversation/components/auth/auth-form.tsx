'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Check } from 'lucide-react'
import { cn } from '@/lib/utils'
import { buttonVariants } from '@/components/ui/button'
import { billingService, PLAN_SELECTION_STORAGE_KEY, type PlanSelection } from '@/lib/billing/service'

const inputClass =
  'w-full rounded-lg border border-border bg-background px-3.5 py-2.5 text-sm outline-none transition-colors focus:border-primary focus:ring-3 focus:ring-ring/30'

export function AuthForm({ mode }: { mode: 'login' | 'signup' }) {
  const router = useRouter()
  const isSignup = mode === 'signup'
  const plans = billingService.getPlans()
  const [selectedPlanId, setSelectedPlanId] = useState(plans[0].id)
  const [interval, setInterval] = useState<PlanSelection['interval']>('monthly')

  useEffect(() => {
    if (!isSignup) return
    const params = new URLSearchParams(window.location.search)
    const requestedPlan = params.get('plan')
    const requestedInterval = params.get('interval')
    if (requestedPlan && plans.some((plan) => plan.id === requestedPlan)) setSelectedPlanId(requestedPlan)
    if (requestedInterval === 'annual' || requestedInterval === 'monthly') setInterval(requestedInterval)
  }, [isSignup, plans])

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (isSignup) {
      window.localStorage.setItem(
        PLAN_SELECTION_STORAGE_KEY,
        JSON.stringify({ planId: selectedPlanId, interval }),
      )
    }
    // Authentication (Supabase Auth) is wired up in a later stage.
    // The selected plan is onboarding preference only until billing is connected.
    router.push('/dashboard')
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      {isSignup && (
        <div className="flex flex-col gap-1.5">
          <label htmlFor="fullName" className="text-sm font-medium">
            Full name
          </label>
          <input id="fullName" name="fullName" required className={inputClass} placeholder="Jane Doe" />
        </div>
      )}

      {isSignup && (
        <fieldset className="rounded-xl border border-border bg-card p-4">
          <legend className="px-1 text-sm font-semibold">Choose your plan</legend>
          <p className="mt-1 text-xs leading-5 text-muted-foreground">
            Your 7-day free trial starts after your first successful website publish.
          </p>
          <div className="mt-3 grid gap-2">
            {plans.map((plan) => {
              const selected = selectedPlanId === plan.id
              return (
                <label
                  key={plan.id}
                  className={cn(
                    'cursor-pointer rounded-lg border p-3 transition-colors',
                    selected ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/40',
                  )}
                >
                  <input
                    type="radio"
                    name="plan"
                    value={plan.id}
                    checked={selected}
                    onChange={() => setSelectedPlanId(plan.id)}
                    className="sr-only"
                  />
                  <span className="flex items-center gap-2">
                    {selected ? <Check className="size-4 text-primary" /> : <span className="size-4 rounded-full border border-border" />}
                    <span className="flex-1 text-sm font-semibold">{plan.name}</span>
                    <span className="text-sm font-bold">${interval === 'monthly' ? plan.monthly : plan.annual}<span className="text-xs font-normal text-muted-foreground">/{interval === 'monthly' ? 'mo' : 'yr'}</span></span>
                  </span>
                </label>
              )
            })}
          </div>
          <div className="mt-3 flex w-fit items-center gap-1 rounded-full border border-border bg-background p-1">
            {(['monthly', 'annual'] as const).map((value) => (
              <button
                key={value}
                type="button"
                onClick={() => setInterval(value)}
                className={cn(
                  'rounded-full px-3 py-1 text-xs font-medium capitalize',
                  interval === value ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground',
                )}
              >
                {value === 'annual' ? 'Yearly' : 'Monthly'}
              </button>
            ))}
          </div>
          <p className="mt-3 text-[11px] leading-4 text-muted-foreground">
            Payment setup is not connected yet. No charge or subscription is created by this selection.
          </p>
        </fieldset>
      )}

      <div className="flex flex-col gap-1.5">
        <label htmlFor="email" className="text-sm font-medium">
          Email
        </label>
        <input
          id="email"
          name="email"
          type="email"
          required
          className={inputClass}
          placeholder="you@company.com"
        />
      </div>

      <div className="flex flex-col gap-1.5">
        <div className="flex items-center justify-between">
          <label htmlFor="password" className="text-sm font-medium">
            Password
          </label>
          {!isSignup && (
            <button type="button" className="text-xs text-primary hover:underline">
              Forgot?
            </button>
          )}
        </div>
        <input
          id="password"
          name="password"
          type="password"
          required
          minLength={8}
          className={inputClass}
          placeholder="••••••••"
        />
      </div>

      <button
        type="submit"
        className={cn(buttonVariants({ size: 'lg' }), 'mt-2 h-11 w-full justify-center')}
      >
        {isSignup ? 'Create account' : 'Log in'}
      </button>

      <p className="text-center text-sm text-muted-foreground">
        {isSignup ? 'Already have an account? ' : "Don't have an account? "}
        <Link
          href={isSignup ? '/login' : '/signup'}
          className="font-medium text-primary hover:underline"
        >
          {isSignup ? 'Log in' : 'Sign up'}
        </Link>
      </p>
    </form>
  )
}
