import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { cn } from '@/lib/utils'
import { buttonVariants } from '@/components/ui/button'
import { Icon } from '@/components/icon'
import { services } from '@/lib/config'

export function ServicesPreview() {
  return (
    <section className="relative overflow-hidden bg-brand-blue-dark text-white">
      <div className="mx-auto w-full max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <span className="text-xs font-semibold uppercase tracking-[0.18em] text-brand-gold">
              PERFI TECH Services
            </span>
            <h2 className="mt-3 text-balance text-3xl font-bold sm:text-4xl">
              Need a hand? Order professional services
            </h2>
            <p className="mt-4 text-pretty text-white/70">
              Beyond the platform, order expert help from {`PERFI TECH's`} team — from
              branding and custom development to SEO and store setup.
            </p>
          </div>
          <Link
            href="/services"
            className={cn(
              buttonVariants({ size: 'lg' }),
              'h-11 bg-brand-gold px-5 text-[oklch(0.28_0.09_80)] hover:bg-brand-gold/90',
            )}
          >
            Browse all services
            <ArrowRight className="ml-1 size-4" />
          </Link>
        </div>

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {services.slice(0, 6).map((service) => (
            <div
              key={service.id}
              className="rounded-xl border border-white/10 bg-white/5 p-6 backdrop-blur transition-colors hover:border-brand-gold/50"
            >
              <div className="flex size-11 items-center justify-center rounded-lg bg-brand-gold/15 text-brand-gold">
                <Icon name={service.icon} className="size-5" />
              </div>
              <h3 className="mt-5 text-lg font-semibold">{service.name}</h3>
              <p className="mt-2 text-sm leading-relaxed text-white/60">
                {service.description}
              </p>
              <p className="mt-4 text-sm font-medium text-white/80">
                From{' '}
                <span className="text-brand-gold">${service.startingPrice}</span>
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
