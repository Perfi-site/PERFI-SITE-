const stats = [
  { value: 'AI + Manual', label: 'Two ways to build' },
  { value: 'Global Edge', label: 'Fast, secure hosting' },
  { value: '1-Click', label: 'Publish anywhere' },
  { value: '24/7', label: 'Support & services' },
]

export function StatsBand() {
  return (
    <section className="border-y border-border bg-secondary/40">
      <div className="mx-auto grid w-full max-w-6xl grid-cols-2 gap-8 px-4 py-12 sm:px-6 lg:grid-cols-4">
        {stats.map((stat) => (
          <div key={stat.label} className="text-center">
            <p className="font-display text-2xl font-bold text-primary sm:text-3xl">
              {stat.value}
            </p>
            <p className="mt-1 text-sm text-muted-foreground">{stat.label}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
