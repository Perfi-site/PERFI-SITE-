import Link from 'next/link'
import Image from 'next/image'
import { ArrowRight } from 'lucide-react'
import { cn } from '@/lib/utils'
import { buttonVariants } from '@/components/ui/button'
import { company, heroActions } from '@/lib/config'

const variantClasses: Record<string, string> = {
  primary: 'bg-primary text-primary-foreground hover:bg-primary/90',
  gold: 'bg-brand-gold text-[oklch(0.28_0.09_80)] hover:bg-brand-gold/90',
  outline:
    'border border-border bg-background/60 text-foreground hover:bg-muted backdrop-blur',
}

export function Hero() {
  return (
    <section className="relative overflow-hidden border-b border-border">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 -z-10 bg-gradient-to-b from-secondary/60 via-background to-background"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-32 -top-32 -z-10 size-96 rounded-full bg-brand-gold/10 blur-3xl"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -left-32 top-40 -z-10 size-96 rounded-full bg-primary/10 blur-3xl"
      />

      <div className="mx-auto grid w-full max-w-6xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
        <div className="flex flex-col items-start">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-background/70 px-3 py-1 text-xs font-medium tracking-[0.12em] text-muted-foreground">
            <span className="size-1.5 rounded-full bg-brand-gold" />
            {company.tagline}
          </span>

          <h1 className="mt-6 text-balance text-4xl font-bold leading-[1.05] sm:text-5xl lg:text-6xl">
            BUILD. PUBLISH. GROW.
            <span className="mt-2 block bg-gradient-to-r from-primary to-brand-gold bg-clip-text text-transparent">
              ALL WITH PERFI-SITE
            </span>
          </h1>

          <p className="mt-6 max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
            Create, launch, host and grow your professional website with PERFI-SITE
            while accessing technology and business services from{' '}
            {company.legalName}.
          </p>

          <div className="mt-8 grid w-full grid-cols-1 gap-3 sm:grid-cols-2">
            {heroActions.map((action) => (
              <Link
                key={action.label}
                href={action.href}
                className={cn(
                  buttonVariants({ size: 'lg' }),
                  'h-12 justify-center px-5 text-sm font-semibold',
                  variantClasses[action.variant],
                )}
              >
                {action.label}
                <ArrowRight className="ml-1 size-4" />
              </Link>
            ))}
          </div>
        </div>

        <div className="relative">
          <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-2xl shadow-primary/10">
            <Image
              src="/hero-dashboard.png"
              alt="PERFI-SITE website builder interface on laptop and mobile"
              width={900}
              height={700}
              className="h-auto w-full object-cover"
              priority
            />
          </div>
        </div>
      </div>
    </section>
  )
}
