import Link from 'next/link'
import { cn } from '@/lib/utils'
import { buttonVariants } from '@/components/ui/button'

export function FinalCta() {
  return (
    <section className="mx-auto w-full max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
      <div className="relative overflow-hidden rounded-3xl border border-border bg-gradient-to-br from-primary to-brand-blue-dark px-6 py-14 text-center text-white sm:px-12">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-20 -top-20 size-72 rounded-full bg-brand-gold/20 blur-3xl"
        />
        <h2 className="mx-auto max-w-2xl text-balance text-3xl font-bold sm:text-4xl">
          Ready to build your global presence?
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-pretty text-white/70">
          Start free, launch in minutes, and grow with the full power of PERFI TECH
          behind you.
        </p>
        <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Link
            href="/signup"
            className={cn(
              buttonVariants({ size: 'lg' }),
              'h-12 bg-brand-gold px-6 text-[oklch(0.28_0.09_80)] hover:bg-brand-gold/90',
            )}
          >
            Create your account
          </Link>
          <Link
            href="/pricing"
            className={cn(
              buttonVariants({ variant: 'outline', size: 'lg' }),
              'h-12 border-white/30 bg-transparent px-6 text-white hover:bg-white/10',
            )}
          >
            View pricing
          </Link>
        </div>
      </div>
    </section>
  )
}
