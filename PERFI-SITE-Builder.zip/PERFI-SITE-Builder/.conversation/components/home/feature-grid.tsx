import { SectionHeading } from '@/components/marketing/section-heading'
import { Icon } from '@/components/icon'
import { products } from '@/lib/config'

export function FeatureGrid() {
  return (
    <section className="mx-auto w-full max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
      <SectionHeading
        eyebrow="One platform"
        title="Everything you need to be online"
        description="From your first prompt to a growing global business — PERFI-SITE brings building, hosting, domains, commerce and analytics together."
      />

      <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {products.map((product) => (
          <div
            key={product.id}
            className="group rounded-xl border border-border bg-card p-6 transition-all hover:border-primary/40 hover:shadow-lg hover:shadow-primary/5"
          >
            <div className="flex size-11 items-center justify-center rounded-lg bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
              <Icon name={product.icon} className="size-5" />
            </div>
            <h3 className="mt-5 text-lg font-semibold">{product.name}</h3>
            <p className="mt-1 text-sm font-medium text-brand-gold">{product.tagline}</p>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              {product.description}
            </p>
          </div>
        ))}
      </div>
    </section>
  )
}
