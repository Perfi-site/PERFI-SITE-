import Link from 'next/link'
import { Logo } from '@/components/logo'
import { company, footerNav } from '@/lib/config'

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-brand-blue-dark text-white">
      <div className="mx-auto w-full max-w-6xl px-4 py-14 sm:px-6">
        <div className="grid gap-10 lg:grid-cols-[1.5fr_repeat(3,1fr)]">
          <div className="max-w-xs">
            <Logo invert showTagline />
            <p className="mt-4 text-sm text-white/60">
              Create, launch, host and grow your professional website — all in one platform.
            </p>
            <p className="mt-4 text-xs font-medium tracking-[0.12em] text-brand-gold">
              {company.tagline}
            </p>
          </div>

          {footerNav.map((group) => (
            <div key={group.title}>
              <h3 className="font-display text-sm font-semibold text-white">{group.title}</h3>
              <ul className="mt-4 space-y-2.5">
                {group.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="text-sm text-white/60 transition-colors hover:text-brand-gold"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col gap-2 border-t border-white/10 pt-6 text-xs text-white/50 sm:flex-row sm:items-center sm:justify-between">
          <p>
            &copy; {new Date().getFullYear()} {company.legalName}. All rights reserved.
          </p>
          <p>{company.product} — a PERFI TECH platform.</p>
        </div>
      </div>
    </footer>
  )
}
