import {
  Sparkles,
  LayoutTemplate,
  Server,
  Globe,
  ShoppingCart,
  BarChart3,
  Palette,
  Code2,
  TrendingUp,
  Store,
  MoveRight,
  Lightbulb,
  type LucideIcon,
} from 'lucide-react'

const registry: Record<string, LucideIcon> = {
  Sparkles,
  LayoutTemplate,
  Server,
  Globe,
  ShoppingCart,
  BarChart3,
  Palette,
  Code2,
  TrendingUp,
  Store,
  MoveRight,
  Lightbulb,
}

export function Icon({
  name,
  className,
}: {
  name: string
  className?: string
}) {
  const Cmp = registry[name] ?? Sparkles
  return <Cmp className={className} aria-hidden="true" />
}
