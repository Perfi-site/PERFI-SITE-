'use client'

import type { CSSProperties, MouseEvent } from 'react'
import type { Page, Section, Site, SiteTheme } from '@/lib/builder/types'
import { themeToCssVars } from '@/lib/builder/theme'

type SiteRendererProps = {
  site: Site
  page: Page
  selectedSectionId?: string | null
  onSelectSection?: (sectionId: string) => void
  preview?: boolean
}

function value<T>(props: Record<string, unknown>, key: string, fallback: T): T {
  const candidate = props[key]
  return (candidate as T | undefined) ?? fallback
}

function stopEditorLink(event: MouseEvent<HTMLAnchorElement>) {
  event.preventDefault()
}

function buttonStyle(theme: SiteTheme, style: string): CSSProperties {
  const shared = { borderRadius: 'var(--site-button-radius)' }
  if (style === 'accent') {
    return { ...shared, backgroundColor: theme.accent, color: '#241a00' }
  }
  if (style === 'outline') {
    return { ...shared, borderColor: theme.primary, color: theme.primary, backgroundColor: 'transparent' }
  }
  return { ...shared, backgroundColor: theme.primary, color: '#ffffff' }
}

function SectionContent({ section, theme, preview }: { section: Section; theme: SiteTheme; preview: boolean }) {
  const props = section.props
  const align = value<string>(props, 'align', 'left')
  const alignClass = align === 'center' ? 'text-center' : align === 'right' ? 'text-right' : 'text-left'
  const muted = { color: `${theme.foreground}99` }

  switch (section.type) {
    case 'navigation': {
      const links = value<{ label: string; href: string }[]>(props, 'links', [])
      return (
        <nav className="flex flex-wrap items-center justify-between gap-5 border-b px-6 py-5 sm:px-10" style={{ borderColor: `${theme.foreground}14` }}>
          <span className="text-lg font-bold tracking-tight" style={{ color: theme.primary }}>
            {value(props, 'brand', 'Your Brand')}
          </span>
          <div className="flex flex-wrap items-center justify-end gap-4 text-sm" style={{ color: theme.foreground }}>
            {links.map((link) => (
              <a key={`${link.label}-${link.href}`} href={link.href} onClick={preview ? undefined : stopEditorLink} className="transition-opacity hover:opacity-60">
                {link.label}
              </a>
            ))}
            <a
              href={value(props, 'ctaHref', '#')}
              onClick={preview ? undefined : stopEditorLink}
              className="rounded-[var(--site-radius)] px-4 py-2 font-semibold"
              style={buttonStyle(theme, 'primary')}
            >
              {value(props, 'ctaLabel', 'Get Started')}
            </a>
          </div>
        </nav>
      )
    }
    case 'hero':
      return (
        <section className="grid gap-10 px-6 py-16 sm:px-10 lg:grid-cols-2 lg:items-center lg:py-24">
          <div className={alignClass}>
            <p className="mb-4 text-xs font-bold uppercase tracking-[0.2em]" style={{ color: theme.accent }}>
              Built for your next chapter
            </p>
            <h1 className="text-4xl font-bold leading-[1.05] tracking-tight sm:text-6xl" style={{ color: theme.foreground }}>
              {value(props, 'heading', 'A headline that sells your idea')}
            </h1>
            <p className="mx-auto mt-6 max-w-xl text-base leading-7 sm:text-lg" style={muted}>
              {value(props, 'subheading', 'A short, compelling description of what you offer and why it matters to your visitors.')}
            </p>
            <div className={`mt-8 flex flex-wrap gap-3 ${align === 'center' ? 'justify-center' : align === 'right' ? 'justify-end' : ''}`}>
              <a href={value(props, 'ctaHref', '#')} onClick={preview ? undefined : stopEditorLink} className="rounded-[var(--site-radius)] px-5 py-3 text-sm font-semibold" style={buttonStyle(theme, 'primary')}>
                {value(props, 'ctaLabel', 'Get Started')}
              </a>
              <a href={value(props, 'secondaryHref', '#about')} onClick={preview ? undefined : stopEditorLink} className="rounded-[var(--site-radius)] border px-5 py-3 text-sm font-semibold" style={buttonStyle(theme, 'outline')}>
                {value(props, 'secondaryLabel', 'Learn More')}
              </a>
            </div>
          </div>
          <div className="overflow-hidden rounded-[calc(var(--site-radius)*1.5)]" style={{ backgroundColor: `${theme.primary}12` }}>
            <img src={value(props, 'image', '/placeholder.svg?height=700&width=1000&query=modern%20product%20hero%20image')} alt={value(props, 'heading', 'Hero image')} className="aspect-[4/3] h-full w-full object-cover" />
          </div>
        </section>
      )
    case 'about':
      return (
        <section className="grid gap-8 px-6 py-12 sm:px-10 lg:grid-cols-2 lg:items-center">
          <div className={align === 'right' ? 'order-2' : ''}>
            <p className="text-xs font-bold uppercase tracking-[0.2em]" style={{ color: theme.accent }}>About us</p>
            <h2 className="mt-3 text-3xl font-bold leading-tight" style={{ color: theme.foreground }}>{value(props, 'heading', 'Built around your customers')}</h2>
            <p className="mt-5 whitespace-pre-wrap text-base leading-8" style={muted}>{value(props, 'body', 'Tell visitors who you are and why your work matters.')}</p>
          </div>
          <img src={value(props, 'image', '/placeholder.svg?height=650&width=900&query=business%20team%20collaborating')} alt={value(props, 'imageAlt', '')} className={`aspect-[4/3] w-full rounded-[var(--site-radius)] object-cover ${align === 'right' ? 'order-1' : ''}`} />
        </section>
      )
    case 'services': {
      const items = value<{ title: string; description: string }[]>(props, 'items', [])
      return (
        <section className="px-6 py-12 sm:px-10" style={{ backgroundColor: `${theme.primary}06` }}>
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold" style={{ color: theme.foreground }}>{value(props, 'heading', 'How we can help')}</h2>
            <p className="mt-3 leading-7" style={muted}>{value(props, 'subheading', '')}</p>
          </div>
          <div className="mx-auto mt-8 grid max-w-5xl gap-4 md:grid-cols-3">
            {items.map((item, index) => <article key={`${item.title}-${index}`} className="rounded-[var(--site-radius)] border p-5" style={{ borderColor: `${theme.foreground}16`, backgroundColor: theme.background }}><div className="flex size-9 items-center justify-center rounded-full text-sm font-bold" style={{ backgroundColor: `${theme.accent}55`, color: theme.foreground }}>{index + 1}</div><h3 className="mt-5 font-semibold" style={{ color: theme.foreground }}>{item.title}</h3><p className="mt-2 text-sm leading-6" style={muted}>{item.description}</p></article>)}
          </div>
        </section>
      )
    }
    case 'products': {
      const items = value<{ name: string; description: string; price: string; image: string; href: string }[]>(props, 'items', [])
      return (
        <section className="px-6 py-12 sm:px-10">
          <h2 className="mb-7 text-2xl font-bold" style={{ color: theme.foreground }}>{value(props, 'heading', 'Featured products')}</h2>
          <div className="grid gap-5 md:grid-cols-3">
            {items.map((item, index) => <article key={`${item.name}-${index}`} className="overflow-hidden rounded-[var(--site-radius)] border" style={{ borderColor: `${theme.foreground}16` }}><img src={item.image} alt={item.name} className="aspect-[4/3] w-full object-cover" /><div className="p-5"><div className="flex items-start justify-between gap-3"><h3 className="font-semibold" style={{ color: theme.foreground }}>{item.name}</h3><span className="shrink-0 text-sm font-bold" style={{ color: theme.primary }}>{item.price}</span></div><p className="mt-2 text-sm leading-6" style={muted}>{item.description}</p><a href={item.href || '#'} onClick={preview ? undefined : stopEditorLink} className="mt-5 inline-flex px-4 py-2 text-sm font-semibold" style={buttonStyle(theme, 'outline')}>View product</a></div></article>)}
          </div>
        </section>
      )
    }
    case 'team': {
      const items = value<{ name: string; role: string; bio: string; image: string }[]>(props, 'items', [])
      return (
        <section className="px-6 py-12 sm:px-10" style={{ backgroundColor: `${theme.primary}06` }}>
          <h2 className="mb-7 text-2xl font-bold" style={{ color: theme.foreground }}>{value(props, 'heading', 'Meet the team')}</h2>
          <div className="grid gap-5 sm:grid-cols-2 md:grid-cols-3">
            {items.map((item, index) => <article key={`${item.name}-${index}`} className="overflow-hidden rounded-[var(--site-radius)] border" style={{ borderColor: `${theme.foreground}16`, backgroundColor: theme.background }}><img src={item.image} alt={item.name} className="aspect-square w-full object-cover" /><div className="p-5"><h3 className="font-semibold" style={{ color: theme.foreground }}>{item.name}</h3><p className="mt-1 text-xs font-semibold uppercase tracking-wider" style={{ color: theme.accent }}>{item.role}</p><p className="mt-3 text-sm leading-6" style={muted}>{item.bio}</p></div></article>)}
          </div>
        </section>
      )
    }
    case 'faq': {
      const items = value<{ question: string; answer: string }[]>(props, 'items', [])
      return (
        <section className="mx-auto max-w-3xl px-6 py-12 sm:px-10">
          <h2 className="mb-7 text-2xl font-bold" style={{ color: theme.foreground }}>{value(props, 'heading', 'Frequently asked questions')}</h2>
          <div className="space-y-3">{items.map((item, index) => <details key={`${item.question}-${index}`} className="rounded-[var(--site-radius)] border p-4" style={{ borderColor: `${theme.foreground}16` }}><summary className="cursor-pointer list-none font-semibold" style={{ color: theme.foreground }}>{item.question}</summary><p className="mt-3 text-sm leading-6" style={muted}>{item.answer}</p></details>)}</div>
        </section>
      )
    }
    case 'cta':
      return (
        <section className={`px-6 py-12 sm:px-10 ${alignClass}`} style={{ backgroundColor: `${theme.primary}10` }}>
          <h2 className="text-3xl font-bold" style={{ color: theme.foreground }}>{value(props, 'heading', 'Ready to take the next step?')}</h2>
          <p className="mx-auto mt-3 max-w-2xl leading-7" style={muted}>{value(props, 'body', 'Give visitors one clear reason to act now.')}</p>
          <a href={value(props, 'ctaHref', '#')} onClick={preview ? undefined : stopEditorLink} className="mt-7 inline-flex px-5 py-3 text-sm font-semibold" style={buttonStyle(theme, 'primary')}>{value(props, 'ctaLabel', 'Get started')}</a>
        </section>
      )
    case 'heading':
      return (
        <section className={`px-6 py-12 sm:px-10 ${alignClass}`}>
          <h2 className="text-3xl font-bold" style={{ color: theme.foreground }}>{value(props, 'text', 'Section heading')}</h2>
          <p className="mx-auto mt-3 max-w-2xl leading-7" style={muted}>{value(props, 'subtitle', 'Supporting text that introduces this section.')}</p>
        </section>
      )
    case 'text':
      return (
        <section className={`px-6 py-10 sm:px-10 ${alignClass}`}>
          <p className="mx-auto max-w-3xl whitespace-pre-wrap text-base leading-8" style={muted}>{value(props, 'body', 'Write your content here.')}</p>
        </section>
      )
    case 'image':
      return (
        <section className="px-6 py-10 sm:px-10">
          <img src={value(props, 'src', '/placeholder.svg?height=600&width=1000&query=feature%20image')} alt={value(props, 'alt', '')} className="mx-auto max-h-[520px] w-full max-w-5xl rounded-[var(--site-radius)] object-cover" />
          {value(props, 'caption', '') && <p className="mt-3 text-center text-sm" style={muted}>{value(props, 'caption', '')}</p>}
        </section>
      )
    case 'video':
      return (
        <section className="px-6 py-10 sm:px-10">
          <div className="mx-auto flex aspect-video max-w-4xl items-center justify-center rounded-[var(--site-radius)] p-8 text-center" style={{ backgroundColor: `${theme.primary}12`, color: theme.primary }}>
            <div>
              <div className="mx-auto mb-3 flex size-14 items-center justify-center rounded-full" style={{ backgroundColor: theme.primary, color: '#fff' }}>▶</div>
              <p className="font-semibold">{value(props, 'title', 'Watch our story')}</p>
              <p className="mt-1 text-xs" style={muted}>{value(props, 'url', 'Add a YouTube or Vimeo URL')}</p>
            </div>
          </div>
        </section>
      )
    case 'button':
      return (
        <section className={`px-6 py-8 sm:px-10 ${alignClass}`}>
          <a href={value(props, 'href', '#')} onClick={preview ? undefined : stopEditorLink} className="inline-flex rounded-[var(--site-radius)] px-5 py-3 text-sm font-semibold" style={buttonStyle(theme, value(props, 'style', 'primary'))}>
            {value(props, 'label', 'Click here')}
          </a>
        </section>
      )
    case 'cards': {
      const items = value<{ title: string; description: string }[]>(props, 'items', [])
      return (
        <section className="px-6 py-12 sm:px-10">
          <h2 className="mb-7 text-2xl font-bold" style={{ color: theme.foreground }}>{value(props, 'heading', 'What we offer')}</h2>
          <div className="grid gap-4 md:grid-cols-3">
            {items.map((item, index) => (
              <article key={`${item.title}-${index}`} className="rounded-[var(--site-radius)] border p-5" style={{ borderColor: `${theme.foreground}16`, backgroundColor: `${theme.primary}05` }}>
                <div className="mb-5 flex size-9 items-center justify-center rounded-lg text-sm font-bold" style={{ backgroundColor: `${theme.accent}55`, color: theme.foreground }}>{String(index + 1).padStart(2, '0')}</div>
                <h3 className="font-semibold" style={{ color: theme.foreground }}>{item.title}</h3>
                <p className="mt-2 text-sm leading-6" style={muted}>{item.description}</p>
              </article>
            ))}
          </div>
        </section>
      )
    }
    case 'testimonials': {
      const items = value<{ quote: string; author: string; role: string }[]>(props, 'items', [])
      return (
        <section className="px-6 py-12 sm:px-10" style={{ backgroundColor: `${theme.primary}08` }}>
          <h2 className="mb-7 text-2xl font-bold" style={{ color: theme.foreground }}>{value(props, 'heading', 'What our clients say')}</h2>
          <div className="grid gap-4 md:grid-cols-2">
            {items.map((item, index) => (
              <blockquote key={`${item.author}-${index}`} className="rounded-[var(--site-radius)] p-6" style={{ backgroundColor: theme.background }}>
                <p className="text-lg leading-7" style={{ color: theme.foreground }}>“{item.quote}”</p>
                <footer className="mt-5 text-sm" style={muted}><strong style={{ color: theme.foreground }}>{item.author}</strong> · {item.role}</footer>
              </blockquote>
            ))}
          </div>
        </section>
      )
    }
    case 'pricing': {
      const items = value<{ name: string; price: string; period: string; features: string[]; ctaLabel: string }[]>(props, 'items', [])
      return (
        <section className="px-6 py-12 sm:px-10">
          <h2 className="mb-7 text-2xl font-bold" style={{ color: theme.foreground }}>{value(props, 'heading', 'Simple pricing')}</h2>
          <div className="grid gap-4 md:grid-cols-2">
            {items.map((item, index) => (
              <article key={`${item.name}-${index}`} className="rounded-[var(--site-radius)] border p-6" style={{ borderColor: index === 1 ? theme.accent : `${theme.foreground}16`, boxShadow: index === 1 ? `0 8px 24px ${theme.accent}22` : undefined }}>
                <h3 className="font-semibold" style={{ color: theme.foreground }}>{item.name}</h3>
                <p className="mt-4 text-4xl font-bold" style={{ color: theme.primary }}>{item.price}<span className="text-sm font-normal" style={muted}>{item.period}</span></p>
                <ul className="mt-5 space-y-2 text-sm" style={muted}>{item.features.map((feature) => <li key={feature}>✓ {feature}</li>)}</ul>
                <a href="#" onClick={preview ? undefined : stopEditorLink} className="mt-6 inline-flex rounded-[var(--site-radius)] px-4 py-2 text-sm font-semibold" style={buttonStyle(theme, index === 1 ? 'accent' : 'outline')}>{item.ctaLabel}</a>
              </article>
            ))}
          </div>
        </section>
      )
    }
    case 'gallery': {
      const images = value<{ src: string; alt: string }[]>(props, 'images', [])
      return (
        <section className="px-6 py-12 sm:px-10">
          <h2 className="mb-7 text-2xl font-bold" style={{ color: theme.foreground }}>{value(props, 'heading', 'Gallery')}</h2>
          <div className="grid gap-3 sm:grid-cols-3">{images.map((image, index) => <img key={`${image.src}-${index}`} src={image.src} alt={image.alt} className="aspect-square w-full rounded-[var(--site-radius)] object-cover" />)}</div>
        </section>
      )
    }
    case 'form': {
      const fields = value<{ label: string; type: string }[]>(props, 'fields', [])
      return (
        <section className="mx-auto max-w-2xl px-6 py-12 sm:px-10">
          <h2 className="text-2xl font-bold" style={{ color: theme.foreground }}>{value(props, 'title', 'Get in touch')}</h2>
          <p className="mt-2 text-sm leading-6" style={muted}>{value(props, 'description', '')}</p>
          <form className="mt-6 space-y-4" onSubmit={(event) => event.preventDefault()}>
            {fields.map((field) => <label key={field.label} className="block text-sm font-medium" style={{ color: theme.foreground }}>{field.label}<input type={field.type === 'textarea' ? 'text' : field.type} className="mt-2 block w-full rounded-[var(--site-radius)] border bg-transparent px-3 py-2.5 font-normal outline-none" style={{ borderColor: `${theme.foreground}20` }} /></label>)}
            <button type="submit" className="rounded-[var(--site-radius)] px-4 py-2.5 text-sm font-semibold" style={buttonStyle(theme, 'primary')}>{value(props, 'submitLabel', 'Send message')}</button>
          </form>
        </section>
      )
    }
    case 'contact':
      return (
        <section className="grid gap-4 px-6 py-12 sm:grid-cols-3 sm:px-10">
          <h2 className="text-2xl font-bold sm:col-span-3" style={{ color: theme.foreground }}>{value(props, 'heading', 'Contact us')}</h2>
          {[
            ['Email', value(props, 'email', 'hello@example.com')],
            ['Phone', value(props, 'phone', '+1 (555) 000-0000')],
            ['Address', value(props, 'address', '123 Business Ave')],
          ].map(([label, text]) => <div key={label} className="rounded-[var(--site-radius)] border p-4" style={{ borderColor: `${theme.foreground}16` }}><p className="text-xs font-semibold uppercase tracking-wider" style={{ color: theme.accent }}>{label}</p><p className="mt-2 text-sm" style={muted}>{text}</p></div>)}
        </section>
      )
    case 'social': {
      const links = value<{ platform: string; href: string }[]>(props, 'links', [])
      return <section className="px-6 py-10 text-center sm:px-10"><h2 className="text-xl font-bold" style={{ color: theme.foreground }}>{value(props, 'heading', 'Follow us')}</h2><div className="mt-4 flex flex-wrap justify-center gap-3">{links.map((link) => <a key={link.platform} href={link.href} onClick={preview ? undefined : stopEditorLink} className="rounded-full border px-4 py-2 text-sm" style={{ borderColor: `${theme.foreground}20`, color: theme.primary }}>{link.platform}</a>)}</div></section>
    }
    case 'footer': {
      const links = value<{ label: string; href: string }[]>(props, 'links', [])
      return <footer className="mt-8 border-t px-6 py-10 sm:px-10" style={{ borderColor: `${theme.foreground}14`, backgroundColor: `${theme.primary}08` }}><div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"><div><p className="font-bold" style={{ color: theme.primary }}>{value(props, 'brand', 'Your Brand')}</p><p className="mt-1 max-w-sm text-sm" style={muted}>{value(props, 'tagline', '')}</p></div><div className="flex flex-wrap gap-4 text-sm" style={muted}>{links.map((link) => <a key={link.label} href={link.href} onClick={preview ? undefined : stopEditorLink}>{link.label}</a>)}</div></div><p className="mt-8 text-xs" style={muted}>{value(props, 'copyright', `© ${new Date().getFullYear()} Your Brand. All rights reserved.`)}</p></footer>
    }
  }
}

export function SiteRenderer({ site, page, selectedSectionId, onSelectSection, preview = false }: SiteRendererProps) {
  const themeStyle = themeToCssVars(site.theme)
  const spacingValues = { compact: '2rem', comfortable: '3.5rem', spacious: '5.5rem' } as const
  return (
    <div className="perfi-site-preview min-h-full overflow-hidden" style={themeStyle}>
      <style>{`.perfi-site-preview section, .perfi-site-preview footer { padding-block: var(--site-section-spacing) !important; }`}</style>
      {page.sections.map((section) => (
        <div
          key={section.id}
          className={`relative ${!preview ? 'group cursor-pointer' : ''} ${selectedSectionId === section.id ? 'z-10 outline outline-2 outline-offset-[-2px]' : ''}`}
          style={{
            ...(selectedSectionId === section.id ? { outlineColor: site.theme.accent } : {}),
            ...(typeof section.props.sectionBackground === 'string' && section.props.sectionBackground ? { backgroundColor: section.props.sectionBackground } : {}),
            ...(typeof section.props.sectionSpacing === 'string' && section.props.sectionSpacing !== 'default'
              ? { '--site-section-spacing': spacingValues[section.props.sectionSpacing as keyof typeof spacingValues] }
              : {}),
          } as CSSProperties}
          onClick={() => onSelectSection?.(section.id)}
        >
          {!preview && selectedSectionId === section.id && (
            <span className="pointer-events-none absolute right-3 top-3 z-20 rounded-full px-2 py-1 text-[10px] font-bold uppercase tracking-wider shadow-sm" style={{ backgroundColor: site.theme.accent, color: '#241a00' }}>
              {section.type}
            </span>
          )}
          <SectionContent section={section} theme={site.theme} preview={preview} />
        </div>
      ))}
    </div>
  )
}