'use client'

import { useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import {
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  Check,
  ChevronDown,
  Copy,
  Eye,
  GripVertical,
  Laptop,
  Monitor,
  Palette,
  PanelLeft,
  PanelRight,
  Plus,
  Save,
  Smartphone,
  Tablet,
  Trash2,
  X,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { createPage, createSection, createSite } from '@/lib/builder/factory'
import { SECTION_ORDER, SECTION_REGISTRY, type Field } from '@/lib/builder/sections'
import { FONT_OPTIONS, THEME_PRESETS } from '@/lib/builder/theme'
import type { Page, Section, SectionType, Site, SiteTheme } from '@/lib/builder/types'
import { getSite, loadDraft, localSiteRepository, saveSite } from '@/lib/builder/storage'
import { SiteRenderer } from './site-renderer'

const iconMap: Record<string, typeof PanelLeft> = {
  Navigation: PanelLeft,
  Megaphone: Monitor,
  Info: PanelRight,
  BriefcaseBusiness: PanelLeft,
  Package: PanelLeft,
  Users: PanelLeft,
  CircleHelp: PanelRight,
  Heading: Laptop,
  Text: PanelRight,
  Image: Palette,
  Video: Eye,
  MousePointerClick: Check,
  ClipboardList: PanelRight,
  LayoutGrid: PanelLeft,
  Quote: Check,
  CircleDollarSign: Check,
  Images: Palette,
  Mail: PanelRight,
  Share2: PanelRight,
  PanelBottom: PanelRight,
}

type Device = 'desktop' | 'tablet' | 'mobile'

const deviceWidths: Record<Device, string> = {
  desktop: 'min(100%, 1080px)',
  tablet: '768px',
  mobile: '390px',
}

function updateArrayItem(items: unknown[], index: number, key: string, next: unknown) {
  return items.map((item, itemIndex) => itemIndex === index ? { ...(item as Record<string, unknown>), [key]: next } : item)
}

function FieldInput({
  field,
  value,
  onChange,
}: {
  field: Field
  value: unknown
  onChange: (value: unknown) => void
}) {
  const stringValue = typeof value === 'string' ? value : ''
  if (field.kind === 'select') {
    return (
      <select value={stringValue} onChange={(event) => onChange(event.target.value)} className="h-9 w-full rounded-lg border border-border bg-background px-2.5 text-sm outline-none focus:border-primary">
        {field.options?.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
      </select>
    )
  }
  if (field.kind === 'textarea') {
    return <textarea value={stringValue} onChange={(event) => onChange(event.target.value)} placeholder={field.placeholder} rows={4} className="w-full resize-y rounded-lg border border-border bg-background px-2.5 py-2 text-sm leading-5 outline-none focus:border-primary" />
  }
  if (field.kind === 'image') {
    return (
      <div className="space-y-2">
        <input value={stringValue} onChange={(event) => onChange(event.target.value)} placeholder="https:// or /image.jpg" className="h-9 w-full rounded-lg border border-border bg-background px-2.5 text-sm outline-none focus:border-primary" />
        <div className="flex items-center gap-2">
          {stringValue && <img src={stringValue} alt="" className="size-12 rounded-md border border-border object-cover" />}
          <p className="text-[11px] leading-4 text-muted-foreground">Use a hosted image URL or a file path in the public folder.</p>
        </div>
      </div>
    )
  }
  if (field.kind === 'stringlist') {
    const items = Array.isArray(value) ? value.filter((item): item is string => typeof item === 'string') : []
    return <textarea value={items.join('\n')} onChange={(event) => onChange(event.target.value.split('\n').filter(Boolean))} placeholder="One item per line" rows={4} className="w-full resize-y rounded-lg border border-border bg-background px-2.5 py-2 text-sm leading-5 outline-none focus:border-primary" />
  }
  return <input value={stringValue} onChange={(event) => onChange(event.target.value)} placeholder={field.placeholder} className="h-9 w-full rounded-lg border border-border bg-background px-2.5 text-sm outline-none focus:border-primary" />
}

function ListField({ field, value, onChange }: { field: Field; value: unknown; onChange: (value: unknown) => void }) {
  const items = Array.isArray(value) ? value as Record<string, unknown>[] : []
  return (
    <div className="space-y-3">
      {items.map((item, index) => (
        <div key={index} className="rounded-lg border border-border bg-muted/30 p-3">
          <div className="mb-3 flex items-center justify-between gap-2">
            <span className="truncate text-xs font-semibold text-foreground">{String(item[field.itemLabelKey ?? 'label'] ?? `Item ${index + 1}`)}</span>
            <button type="button" onClick={() => onChange(items.filter((_, itemIndex) => itemIndex !== index))} className="rounded p-1 text-muted-foreground hover:bg-destructive/10 hover:text-destructive" aria-label="Remove item"><Trash2 className="size-3.5" /></button>
          </div>
          <div className="space-y-3">
            {field.itemFields?.map((itemField) => (
              <label key={itemField.key} className="block space-y-1.5">
                <span className="text-[11px] font-medium text-muted-foreground">{itemField.label}</span>
                <FieldInput field={itemField} value={item[itemField.key]} onChange={(next) => onChange(updateArrayItem(items, index, itemField.key, next))} />
              </label>
            ))}
          </div>
        </div>
      ))}
      <button
        type="button"
        onClick={() => onChange([...items, Object.fromEntries((field.itemFields ?? []).map((itemField) => [itemField.key, itemField.kind === 'stringlist' ? [] : '']))])}
        className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-dashed border-border px-3 py-2 text-xs font-semibold text-muted-foreground transition-colors hover:border-primary hover:text-primary"
      >
        <Plus className="size-3.5" /> Add {field.label.replace(/s$/, '')}
      </button>
    </div>
  )
}

function Inspector({ section, onChange }: { section: Section; onChange: (patch: Record<string, unknown>) => void }) {
  const descriptor = SECTION_REGISTRY[section.type]
  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs font-bold uppercase tracking-[0.16em] text-brand-gold">{descriptor.label}</p>
        <p className="mt-1 text-xs leading-5 text-muted-foreground">{descriptor.description}</p>
      </div>
      <div className="space-y-4">
        {descriptor.fields.map((field) => (
          <label key={field.key} className="block space-y-1.5">
            <span className="text-xs font-semibold text-foreground">{field.label}</span>
            {field.kind === 'list' ? (
              <ListField field={field} value={section.props[field.key]} onChange={(value) => onChange({ [field.key]: value })} />
            ) : (
              <FieldInput field={field} value={section.props[field.key]} onChange={(value) => onChange({ [field.key]: value })} />
            )}
          </label>
        ))}
      </div>
    </div>
  )
}

function SectionSettings({ section, onChange }: { section: Section; onChange: (patch: Record<string, unknown>) => void }) {
  const background = typeof section.props.sectionBackground === 'string' ? section.props.sectionBackground : ''
  const spacing = typeof section.props.sectionSpacing === 'string' ? section.props.sectionSpacing : 'default'
  return (
    <div className="mt-6 border-t border-border pt-5">
      <p className="text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground">Section settings</p>
      <div className="mt-4 space-y-4">
        <label className="block space-y-1.5">
          <span className="text-xs font-semibold">Background color</span>
          <div className="flex h-9 items-center gap-2 rounded-lg border border-border bg-background px-2">
            <input type="color" value={background || '#ffffff'} onChange={(event) => onChange({ sectionBackground: event.target.value })} className="size-5 cursor-pointer rounded border-0 bg-transparent p-0" />
            <button type="button" onClick={() => onChange({ sectionBackground: '' })} className="text-[11px] text-muted-foreground hover:text-foreground">{background ? 'Reset' : 'Use theme background'}</button>
          </div>
        </label>
        <label className="block space-y-1.5">
          <span className="text-xs font-semibold">Section spacing</span>
          <select value={spacing} onChange={(event) => onChange({ sectionSpacing: event.target.value })} className="h-9 w-full rounded-lg border border-border bg-background px-2.5 text-sm outline-none focus:border-primary">
            <option value="default">Use theme spacing</option>
            <option value="compact">Compact</option>
            <option value="comfortable">Comfortable</option>
            <option value="spacious">Spacious</option>
          </select>
        </label>
      </div>
    </div>
  )
}

function ThemePanel({ theme, onChange }: { theme: SiteTheme; onChange: (theme: SiteTheme) => void }) {
  const update = (patch: Partial<SiteTheme>) => onChange({ ...theme, ...patch })
  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs font-bold uppercase tracking-[0.16em] text-brand-gold">Site theme</p>
        <p className="mt-1 text-xs leading-5 text-muted-foreground">Set the visual language for every page in this site.</p>
      </div>
      <div>
        <p className="mb-2 text-xs font-semibold">Quick palettes</p>
        <div className="grid grid-cols-2 gap-2">
          {THEME_PRESETS.map((preset) => (
            <button key={preset.name} type="button" onClick={() => update({ primary: preset.primary, accent: preset.accent })} className="flex items-center gap-2 rounded-lg border border-border p-2 text-left text-[11px] hover:border-primary">
              <span className="flex size-6 shrink-0 overflow-hidden rounded-full"><span className="w-1/2" style={{ backgroundColor: preset.primary }} /><span className="w-1/2" style={{ backgroundColor: preset.accent }} /></span>
              <span className="truncate">{preset.name}</span>
            </button>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {([['primary', 'Primary'], ['accent', 'Accent'], ['background', 'Background'], ['foreground', 'Text']] as const).map(([key, label]) => (
          <label key={key} className="space-y-1.5">
            <span className="text-[11px] font-medium text-muted-foreground">{label}</span>
            <span className="flex h-9 items-center gap-2 rounded-lg border border-border bg-background px-2">
              <input type="color" value={theme[key]} onChange={(event) => update({ [key]: event.target.value })} className="size-5 cursor-pointer rounded border-0 bg-transparent p-0" />
              <span className="text-[10px] uppercase text-muted-foreground">{theme[key]}</span>
            </span>
          </label>
        ))}
      </div>
      <label className="block space-y-1.5">
        <span className="text-xs font-semibold">Heading font</span>
        <select value={theme.fontHeading} onChange={(event) => update({ fontHeading: event.target.value })} className="h-9 w-full rounded-lg border border-border bg-background px-2.5 text-sm">
          {FONT_OPTIONS.map((font) => <option key={font.value} value={font.value}>{font.label}</option>)}
        </select>
      </label>
      <label className="block space-y-1.5">
        <span className="text-xs font-semibold">Body font</span>
        <select value={theme.fontBody} onChange={(event) => update({ fontBody: event.target.value })} className="h-9 w-full rounded-lg border border-border bg-background px-2.5 text-sm">
          {FONT_OPTIONS.map((font) => <option key={font.value} value={font.value}>{font.label}</option>)}
        </select>
      </label>
      <label className="block space-y-1.5">
        <span className="flex justify-between text-xs font-semibold"><span>Corner radius</span><span className="font-normal text-muted-foreground">{theme.radius}px</span></span>
        <input type="range" min="0" max="28" value={theme.radius} onChange={(event) => update({ radius: Number(event.target.value) })} className="w-full accent-[var(--brand-blue)]" />
      </label>
      <label className="block space-y-1.5">
        <span className="text-xs font-semibold">Button style</span>
        <select value={theme.buttonStyle ?? 'solid'} onChange={(event) => update({ buttonStyle: event.target.value as SiteTheme['buttonStyle'] })} className="h-9 w-full rounded-lg border border-border bg-background px-2.5 text-sm">
          <option value="solid">Solid</option>
          <option value="soft">Soft corners</option>
          <option value="pill">Pill</option>
        </select>
      </label>
      <label className="block space-y-1.5">
        <span className="text-xs font-semibold">Section spacing</span>
        <select value={theme.spacing ?? 'comfortable'} onChange={(event) => update({ spacing: event.target.value as SiteTheme['spacing'] })} className="h-9 w-full rounded-lg border border-border bg-background px-2.5 text-sm">
          <option value="compact">Compact</option>
          <option value="comfortable">Comfortable</option>
          <option value="spacious">Spacious</option>
        </select>
      </label>
    </div>
  )
}

export function ManualBuilder() {
  const [site, setSite] = useState<Site>(() => createSite({ name: 'My first website', buildMode: 'manual', template: 'business' }))
  const [activePageId, setActivePageId] = useState('')
  const [selectedSectionId, setSelectedSectionId] = useState<string | null>(null)
  const [device, setDevice] = useState<Device>('desktop')
  const [rightPanel, setRightPanel] = useState<'section' | 'theme'>('section')
  const [preview, setPreview] = useState(false)
  const [savedMessage, setSavedMessage] = useState('')
  const [hydrated, setHydrated] = useState(false)
  const [mobilePanel, setMobilePanel] = useState<'sections' | 'edit' | 'theme' | null>(null)
  const [draggingSectionId, setDraggingSectionId] = useState<string | null>(null)

  useEffect(() => {
    const siteId = new URLSearchParams(window.location.search).get('siteId')
    const existing = siteId ? getSite(siteId) : loadDraft()
    if (existing) setSite(existing)
    setHydrated(true)
  }, [])

  useEffect(() => {
    if (!activePageId && site.pages[0]) setActivePageId(site.pages[0].id)
  }, [activePageId, site.pages])

  const activePage = useMemo(() => site.pages.find((page) => page.id === activePageId) ?? site.pages[0], [activePageId, site.pages])
  const selectedSection = activePage?.sections.find((section) => section.id === selectedSectionId) ?? null

  const replaceSite = (next: Site) => setSite({ ...next, updatedAt: new Date().toISOString() })
  const updatePage = (nextPage: Page) => replaceSite({ ...site, pages: site.pages.map((page) => page.id === nextPage.id ? nextPage : page) })
  const updateSection = (sectionId: string, patch: Record<string, unknown>) => {
    if (!activePage) return
    updatePage({ ...activePage, sections: activePage.sections.map((section) => section.id === sectionId ? { ...section, props: { ...section.props, ...patch } } : section) })
  }
  const moveSection = (sectionId: string, direction: -1 | 1) => {
    if (!activePage) return
    const index = activePage.sections.findIndex((section) => section.id === sectionId)
    const nextIndex = index + direction
    if (index < 0 || nextIndex < 0 || nextIndex >= activePage.sections.length) return
    const sections = [...activePage.sections]
    const [item] = sections.splice(index, 1)
    sections.splice(nextIndex, 0, item)
    updatePage({ ...activePage, sections })
  }
  const reorderSection = (fromId: string, toId: string) => {
    if (!activePage || fromId === toId) return
    const fromIndex = activePage.sections.findIndex((section) => section.id === fromId)
    const toIndex = activePage.sections.findIndex((section) => section.id === toId)
    if (fromIndex < 0 || toIndex < 0) return
    const sections = [...activePage.sections]
    const [item] = sections.splice(fromIndex, 1)
    sections.splice(toIndex, 0, item)
    updatePage({ ...activePage, sections })
  }
  const addSection = (type: SectionType) => {
    if (!activePage) return
    const section = createSection(type)
    const footerIndex = activePage.sections.findIndex((item) => item.type === 'footer')
    const insertAt = footerIndex >= 0 ? footerIndex : activePage.sections.length
    const sections = [...activePage.sections]
    sections.splice(insertAt, 0, section)
    updatePage({ ...activePage, sections })
    setSelectedSectionId(section.id)
    setRightPanel('section')
    setMobilePanel('edit')
  }
  const duplicateSection = (sectionId: string) => {
    if (!activePage) return
    const index = activePage.sections.findIndex((section) => section.id === sectionId)
    if (index < 0) return
    const source = activePage.sections[index]
    const copy = createSection(source.type, JSON.parse(JSON.stringify(source.props)) as Record<string, unknown>)
    const sections = [...activePage.sections]
    sections.splice(index + 1, 0, copy)
    updatePage({ ...activePage, sections })
    setSelectedSectionId(copy.id)
    setRightPanel('section')
    setMobilePanel('edit')
  }
  const addPage = () => {
    const name = window.prompt('New page name', 'New Page')?.trim()
    if (!name) return
    const page = createPage(name, [createSection('navigation'), createSection('heading', { text: name, align: 'center' }), createSection('footer')])
    replaceSite({ ...site, pages: [...site.pages, page] })
    setActivePageId(page.id)
    setSelectedSectionId(page.sections[1].id)
  }
  const duplicatePage = () => {
    if (!activePage) return
    const page = { ...activePage, id: `${activePage.id}-copy-${Date.now()}`, name: `${activePage.name} copy`, slug: `${activePage.slug}-copy`, sections: activePage.sections.map((section) => ({ ...section, id: `${section.id}-copy-${Date.now()}` })) }
    replaceSite({ ...site, pages: [...site.pages, page] })
    setActivePageId(page.id)
  }
  const handleSave = () => {
    saveSite(site)
    setSavedMessage('Saved just now')
    window.setTimeout(() => setSavedMessage(''), 2200)
  }
  const handlePublish = () => {
    const next = localSiteRepository.publishSite(site.id)
    if (next) {
      setSite(next)
      setSavedMessage('Published to your PERFI-SITE subdomain')
    }
  }

  if (!hydrated || !activePage) return <div className="flex min-h-[70vh] items-center justify-center text-sm text-muted-foreground">Loading builder…</div>

  if (preview) {
    return (
      <div className="fixed inset-0 z-50 flex flex-col bg-muted/80">
        <div className="flex h-14 items-center justify-between border-b border-border bg-background px-4 shadow-sm">
          <div className="flex items-center gap-3"><Eye className="size-4 text-primary" /><span className="text-sm font-semibold">Preview · {site.name}</span><span className="rounded-full bg-muted px-2 py-1 text-[10px] font-medium text-muted-foreground">{activePage.name}</span></div>
          <Button variant="outline" size="sm" onClick={() => setPreview(false)}><X className="size-3.5" /> Exit preview</Button>
        </div>
        <div className="flex-1 overflow-auto p-4 sm:p-8"><div className="mx-auto max-w-6xl overflow-hidden rounded-xl bg-background shadow-2xl"><SiteRenderer site={site} page={activePage} preview /></div></div>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 z-40 flex min-h-screen flex-col bg-muted/40">
      <header className="flex h-16 shrink-0 items-center justify-between gap-3 border-b border-border bg-background px-3 sm:px-5">
        <div className="flex min-w-0 items-center gap-2 sm:gap-4">
          <Link href="/dashboard/sites" className="flex size-8 shrink-0 items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground" aria-label="Back to My Sites"><ArrowLeft className="size-4" /></Link>
          <div className="min-w-0"><p className="truncate text-sm font-semibold">{site.name}</p><p className="text-[11px] text-muted-foreground">{site.status === 'published' ? 'Published' : 'Draft'} · {site.subdomain}</p></div>
        </div>
        <div className="flex items-center gap-2">
          {savedMessage && <span className="hidden text-xs text-muted-foreground sm:inline">{savedMessage}</span>}
          <Button variant="outline" size="sm" onClick={() => setPreview(true)}><Eye className="size-3.5" /> <span className="hidden sm:inline">Preview</span></Button>
          <Button variant="outline" size="sm" onClick={handleSave}><Save className="size-3.5" /> <span className="hidden sm:inline">Save</span></Button>
          <Button size="sm" onClick={handlePublish}><Check className="size-3.5" /> Publish</Button>
        </div>
      </header>
      <div className="flex min-h-0 flex-1">
        <aside className="hidden w-64 shrink-0 overflow-y-auto border-r border-border bg-background p-4 lg:block">
          <div className="flex items-center justify-between"><p className="text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground">Pages</p><button type="button" onClick={addPage} className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-primary" aria-label="Add page"><Plus className="size-4" /></button></div>
          <div className="mt-3 space-y-1">
            {site.pages.map((page) => <button key={page.id} type="button" onClick={() => { setActivePageId(page.id); setSelectedSectionId(page.sections[0]?.id ?? null) }} className={cn('flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm', page.id === activePage.id ? 'bg-primary/10 font-semibold text-primary' : 'text-muted-foreground hover:bg-muted hover:text-foreground')}><span>{page.name}</span><span className="text-[10px] opacity-60">/{page.slug}</span></button>)}
          </div>
          <button type="button" onClick={duplicatePage} className="mt-2 flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium text-muted-foreground hover:bg-muted hover:text-foreground"><Copy className="size-3.5" /> Duplicate page</button>
          <div className="mt-8 flex items-center justify-between"><p className="text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground">Sections</p><span className="text-[10px] text-muted-foreground">{activePage.sections.length}</span></div>
          <div className="mt-3 space-y-1">
            {activePage.sections.map((section, index) => { const Icon = iconMap[SECTION_REGISTRY[section.type].icon] ?? PanelLeft; return <button key={section.id} type="button" draggable onDragStart={() => setDraggingSectionId(section.id)} onDragEnd={() => setDraggingSectionId(null)} onDragOver={(event) => event.preventDefault()} onDrop={() => { if (draggingSectionId) reorderSection(draggingSectionId, section.id); setDraggingSectionId(null) }} onClick={() => { setSelectedSectionId(section.id); setRightPanel('section') }} className={cn('flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs', section.id === selectedSectionId ? 'bg-brand-gold/20 font-semibold text-foreground' : 'text-muted-foreground hover:bg-muted hover:text-foreground', draggingSectionId === section.id && 'opacity-40')}><GripVertical className="size-3.5 shrink-0 opacity-50" /><Icon className="size-3.5 shrink-0" /><span className="truncate">{SECTION_REGISTRY[section.type].label}</span><span className="ml-auto text-[10px] opacity-50">{index + 1}</span></button> })}
          </div>
          <div className="mt-5 grid grid-cols-2 gap-2">
            <Button variant="outline" size="sm" onClick={() => selectedSectionId && moveSection(selectedSectionId, -1)} disabled={!selectedSectionId}><ArrowUp className="size-3.5" /> Up</Button>
            <Button variant="outline" size="sm" onClick={() => selectedSectionId && moveSection(selectedSectionId, 1)} disabled={!selectedSectionId}><ArrowDown className="size-3.5" /> Down</Button>
          </div>
          <Button variant="outline" size="sm" onClick={() => selectedSectionId && duplicateSection(selectedSectionId)} disabled={!selectedSectionId} className="mt-2 w-full"><Copy className="size-3.5" /> Duplicate selected section</Button>
        </aside>
        <main className="min-w-0 flex-1 overflow-auto bg-muted/50">
          <div className="flex min-h-full flex-col">
            <div className="flex shrink-0 items-center justify-center gap-1 border-b border-border bg-background px-3 py-2">
              {([['desktop', Monitor], ['tablet', Tablet], ['mobile', Smartphone]] as const).map(([value, Icon]) => <button key={value} type="button" onClick={() => setDevice(value)} className={cn('flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs capitalize', device === value ? 'bg-primary/10 font-semibold text-primary' : 'text-muted-foreground hover:bg-muted')}><Icon className="size-3.5" />{value}</button>)}
            </div>
            <div className="flex flex-1 justify-center overflow-auto p-4 sm:p-8">
              <div className="h-fit w-full overflow-hidden rounded-xl border border-border bg-background shadow-lg transition-all" style={{ maxWidth: deviceWidths[device] }}><SiteRenderer site={site} page={activePage} selectedSectionId={selectedSectionId} onSelectSection={(id) => { setSelectedSectionId(id); setRightPanel('section'); setMobilePanel('edit') }} /></div>
            </div>
          </div>
        </main>
        <aside className="hidden w-80 shrink-0 overflow-y-auto border-l border-border bg-background p-5 lg:block">
          <div className="mb-5 flex items-center gap-1 rounded-lg bg-muted p-1">
            <button type="button" onClick={() => setRightPanel('section')} className={cn('flex flex-1 items-center justify-center gap-1.5 rounded-md py-1.5 text-xs font-medium', rightPanel === 'section' ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground')}><PanelRight className="size-3.5" /> Edit</button>
            <button type="button" onClick={() => setRightPanel('theme')} className={cn('flex flex-1 items-center justify-center gap-1.5 rounded-md py-1.5 text-xs font-medium', rightPanel === 'theme' ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground')}><Palette className="size-3.5" /> Theme</button>
          </div>
          {rightPanel === 'theme' ? <ThemePanel theme={site.theme} onChange={(theme) => replaceSite({ ...site, theme })} /> : selectedSection ? <><div className="mb-4 flex items-center justify-between"><p className="text-xs text-muted-foreground">Editing section</p><button type="button" onClick={() => setSelectedSectionId(null)} className="text-muted-foreground hover:text-foreground" aria-label="Deselect section"><X className="size-4" /></button></div><Inspector section={selectedSection} onChange={(patch) => updateSection(selectedSection.id, patch)} /><SectionSettings section={selectedSection} onChange={(patch) => updateSection(selectedSection.id, patch)} /><div className="mt-5 grid grid-cols-2 gap-2"><Button variant="outline" size="sm" onClick={() => duplicateSection(selectedSection.id)}><Copy className="size-3.5" /> Duplicate</Button><button type="button" onClick={() => { updatePage({ ...activePage, sections: activePage.sections.filter((section) => section.id !== selectedSection.id) }); setSelectedSectionId(null) }} className="flex items-center justify-center gap-2 rounded-lg border border-destructive/20 px-3 py-2 text-xs font-semibold text-destructive hover:bg-destructive/10"><Trash2 className="size-3.5" /> Remove</button></div></> : <div className="py-8 text-center"><PanelRight className="mx-auto size-8 text-muted-foreground/50" /><p className="mt-3 text-sm font-medium">Select a section</p><p className="mt-1 text-xs leading-5 text-muted-foreground">Click a section in the canvas or choose one from the left panel to edit its content.</p></div>}
          <div className="mt-8 border-t border-border pt-5"><p className="text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground">Add section</p><div className="mt-3 grid grid-cols-2 gap-2">{SECTION_ORDER.map((type) => { const descriptor = SECTION_REGISTRY[type]; const Icon = iconMap[descriptor.icon] ?? PanelLeft; return <button key={type} type="button" onClick={() => addSection(type)} className="flex items-center gap-2 rounded-lg border border-border px-2.5 py-2 text-left text-[11px] font-medium hover:border-primary hover:text-primary"><Icon className="size-3.5 shrink-0" />{descriptor.label}</button> })}</div></div>
        </aside>
      </div>
      <div className="grid shrink-0 grid-cols-3 border-t border-border bg-background p-2 lg:hidden">
        <button type="button" onClick={() => setMobilePanel('sections')} className={cn('flex min-h-11 items-center justify-center gap-2 rounded-lg text-xs font-semibold', mobilePanel === 'sections' ? 'bg-primary/10 text-primary' : 'text-muted-foreground')}><PanelLeft className="size-4" /> Sections</button>
        <button type="button" onClick={() => setMobilePanel('edit')} className={cn('flex min-h-11 items-center justify-center gap-2 rounded-lg text-xs font-semibold', mobilePanel === 'edit' ? 'bg-primary/10 text-primary' : 'text-muted-foreground')}><PanelRight className="size-4" /> Edit</button>
        <button type="button" onClick={() => setMobilePanel('theme')} className={cn('flex min-h-11 items-center justify-center gap-2 rounded-lg text-xs font-semibold', mobilePanel === 'theme' ? 'bg-primary/10 text-primary' : 'text-muted-foreground')}><Palette className="size-4" /> Theme</button>
      </div>
      {mobilePanel && <div className="fixed inset-x-0 bottom-0 z-50 max-h-[78vh] overflow-y-auto rounded-t-2xl border border-border bg-background p-4 shadow-2xl lg:hidden">
        <div className="mb-4 flex items-center justify-between"><p className="text-sm font-semibold">{mobilePanel === 'sections' ? 'Pages & sections' : mobilePanel === 'edit' ? 'Edit section' : 'Theme editor'}</p><button type="button" onClick={() => setMobilePanel(null)} className="rounded-md p-2 text-muted-foreground hover:bg-muted" aria-label="Close panel"><X className="size-4" /></button></div>
        {mobilePanel === 'theme' && <ThemePanel theme={site.theme} onChange={(theme) => replaceSite({ ...site, theme })} />}
        {mobilePanel === 'edit' && (selectedSection ? <><Inspector section={selectedSection} onChange={(patch) => updateSection(selectedSection.id, patch)} /><SectionSettings section={selectedSection} onChange={(patch) => updateSection(selectedSection.id, patch)} /><div className="mt-5 grid grid-cols-2 gap-2"><Button variant="outline" size="sm" onClick={() => duplicateSection(selectedSection.id)}><Copy className="size-3.5" /> Duplicate</Button><button type="button" onClick={() => { updatePage({ ...activePage, sections: activePage.sections.filter((section) => section.id !== selectedSection.id) }); setSelectedSectionId(null); setMobilePanel(null) }} className="flex items-center justify-center gap-2 rounded-lg border border-destructive/20 px-3 py-2 text-xs font-semibold text-destructive hover:bg-destructive/10"><Trash2 className="size-3.5" /> Remove</button></div></> : <div className="py-8 text-center text-sm text-muted-foreground">Tap a section in the preview or choose one from the Sections panel.</div>)}
        {mobilePanel === 'sections' && <div className="space-y-6">
          <div><div className="flex items-center justify-between"><p className="text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground">Pages</p><button type="button" onClick={addPage} className="rounded-md p-2 text-muted-foreground hover:bg-muted hover:text-primary" aria-label="Add page"><Plus className="size-4" /></button></div><div className="mt-2 grid gap-1">{site.pages.map((page) => <button key={page.id} type="button" onClick={() => { setActivePageId(page.id); setSelectedSectionId(page.sections[0]?.id ?? null) }} className={cn('flex min-h-11 items-center justify-between rounded-lg px-3 text-left text-sm', page.id === activePage.id ? 'bg-primary/10 font-semibold text-primary' : 'text-muted-foreground hover:bg-muted')}><span>{page.name}</span><span className="text-[10px] opacity-60">/{page.slug}</span></button>)}</div></div>
          <div><p className="text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground">Sections</p><div className="mt-2 grid gap-1">{activePage.sections.map((section, index) => { const Icon = iconMap[SECTION_REGISTRY[section.type].icon] ?? PanelLeft; return <button key={section.id} type="button" onClick={() => { setSelectedSectionId(section.id); setMobilePanel('edit') }} className={cn('flex min-h-11 items-center gap-2 rounded-lg px-3 text-left text-sm', section.id === selectedSectionId ? 'bg-brand-gold/20 font-semibold' : 'text-muted-foreground hover:bg-muted')}><Icon className="size-4" /><span className="truncate">{index + 1}. {SECTION_REGISTRY[section.type].label}</span></button> })}</div></div>
          <div><p className="text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground">Add section</p><div className="mt-2 grid grid-cols-2 gap-2">{SECTION_ORDER.map((type) => { const descriptor = SECTION_REGISTRY[type]; const Icon = iconMap[descriptor.icon] ?? PanelLeft; return <button key={type} type="button" onClick={() => addSection(type)} className="flex min-h-11 items-center gap-2 rounded-lg border border-border px-3 text-left text-xs font-medium hover:border-primary hover:text-primary"><Icon className="size-4 shrink-0" />{descriptor.label}</button> })}</div></div>
        </div>}
      </div>}
    </div>
  )
}