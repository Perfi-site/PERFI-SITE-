import Link from 'next/link'
import Image from 'next/image'
import { cn } from '@/lib/utils'

export function Logo({
  className,
  showTagline = false,
  invert = false,
}: {
  className?: string
  showTagline?: boolean
  invert?: boolean
}) {
  return (
    <Link
      href="/"
      className={cn('inline-flex items-center gap-2.5', className)}
      aria-label="PERFI-SITE home"
    >
      <Image
        src="/perfi-mark.png"
        alt=""
        width={36}
        height={36}
        className="size-9 rounded-md object-contain"
        priority
      />
      <span className="flex flex-col leading-none">
        <span
          className={cn(
            'font-display text-lg font-bold tracking-tight',
            invert ? 'text-white' : 'text-foreground',
          )}
        >
          PERFI<span className="text-brand-gold">-SITE</span>
        </span>
        {showTagline && (
          <span
            className={cn(
              'mt-1 text-[10px] font-medium tracking-[0.15em]',
              invert ? 'text-white/60' : 'text-muted-foreground',
            )}
          >
            BY PERFI TECH GLOBAL
          </span>
        )}
      </span>
    </Link>
  )
}
