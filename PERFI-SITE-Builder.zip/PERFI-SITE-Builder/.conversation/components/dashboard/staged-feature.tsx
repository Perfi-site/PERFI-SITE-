import type { LucideIcon } from 'lucide-react'
import { Construction } from 'lucide-react'

export function StagedFeature({
  title,
  description,
  icon: Icon,
  points,
}: {
  title: string
  description: string
  icon: LucideIcon
  points: string[]
}) {
  return (
    <div className="mx-auto max-w-3xl">
      <div className="flex items-center gap-4">
        <div className="flex size-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <Icon className="size-6" aria-hidden="true" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">{title}</h1>
          <p className="mt-1 text-sm text-muted-foreground">{description}</p>
        </div>
      </div>

      <div className="mt-8 rounded-2xl border border-dashed border-border bg-card p-8">
        <div className="flex items-center gap-2 text-sm font-medium text-brand-gold">
          <Construction className="size-4" aria-hidden="true" />
          Ready for integration
        </div>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          The interface for this module is scaffolded. Live functionality connects in a later
          stage once the backend, database and third-party integrations are enabled. This
          module will support:
        </p>
        <ul className="mt-5 grid gap-2 sm:grid-cols-2">
          {points.map((point) => (
            <li
              key={point}
              className="flex items-start gap-2 rounded-lg bg-muted/60 px-3 py-2 text-sm text-foreground"
            >
              <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-primary" />
              {point}
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
