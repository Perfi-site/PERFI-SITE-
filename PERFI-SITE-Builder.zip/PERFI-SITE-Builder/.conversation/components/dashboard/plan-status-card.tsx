'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { ArrowUpRight, CalendarDays, CreditCard } from 'lucide-react'
import { cn } from '@/lib/utils'
import { buttonVariants } from '@/components/ui/button'
import { billingService, PLAN_SELECTION_STORAGE_KEY, type PlanSelection } from '@/lib/billing/service'
import { localSiteRepository, type TrialStatus } from '@/lib/builder/storage'

export function PlanStatusCard() {
  const [selection, setSelection] = useState<PlanSelection | null>(null)
  const [trial, setTrial] = useState<TrialStatus>(localSiteRepository.getTrialStatus())

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(PLAN_SELECTION_STORAGE_KEY)
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<PlanSelection>
        const validPlan = billingService.getPlans().some((plan) => plan.id === parsed.planId)
        if (validPlan && (parsed.interval === 'monthly' || parsed.interval === 'annual')) {
          setSelection({ planId: parsed.planId!, interval: parsed.interval })
        }
      }
    } catch {
      setSelection(null)
    }
    setTrial(localSiteRepository.getTrialStatus())
  }, [])

  const plan = selection ? billingService.getPlans().find((item) => item.id === selection.planId) : null
  const planPrice = plan ? (selection?.interval === 'annual' ? plan.annual : plan.monthly) : null

  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="flex items-start gap-3">
          <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <CreditCard className="size-5" aria-hidden="true" />
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">Plan selection</p>
            <h2 className="mt-1 text-lg font-semibold">{plan ? plan.name : 'No plan selected'}</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              {plan
                ? `$${planPrice}/${selection?.interval === 'annual' ? 'year' : 'month'} · preference only`
                : 'Choose a simple plan for your onboarding preference.'}
            </p>
          </div>
        </div>
        <Link href="/pricing" className={cn(buttonVariants({ variant: 'outline', size: 'sm' }), 'w-fit')}>
          {plan ? 'Change plan' : 'View plans'} <ArrowUpRight className="size-3.5" />
        </Link>
      </div>
      <div className="mt-5 flex items-center gap-2 rounded-lg bg-muted/60 px-3 py-2.5 text-xs text-muted-foreground">
        <CalendarDays className="size-4 shrink-0 text-brand-gold" />
        <span>
          {trial.state === 'active'
            ? `Free trial active · ${trial.daysRemaining} ${trial.daysRemaining === 1 ? 'day' : 'days'} remaining`
            : trial.state === 'expired'
              ? 'Free trial ended · websites remain available as drafts'
              : 'Free trial starts after your first successful website publish'}
        </span>
      </div>
      <p className="mt-3 text-[11px] leading-4 text-muted-foreground">
        Payment checkout is not connected yet. No payment or paid subscription is created from this dashboard.
      </p>
    </div>
  )
}