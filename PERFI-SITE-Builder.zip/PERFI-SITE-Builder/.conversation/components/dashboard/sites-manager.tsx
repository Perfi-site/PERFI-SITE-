'use client'

import { useEffect, useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import {
  Archive,
  ArrowUpRight,
  CalendarDays,
  Check,
  Copy,
  Eye,
  Globe2,
  LayoutTemplate,
  MoreHorizontal,
  PanelsTopLeft,
  Pencil,
  Plus,
  RotateCcw,
  Settings2,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { buttonVariants, Button } from '@/components/ui/button'
import { slugify } from '@/lib/builder/factory'
import type { ManualTemplate } from '@/lib/builder/factory'
import type { Site } from '@/lib/builder/types'
import {
  localSiteRepository,
  type TrialStatus,
} from '@/lib/builder/storage'

type SiteFilter = 'active' | 'archived'

function formatDate(value: string) {
  return new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric', year: 'numeric' }).format(new Date(value))
}

function statusLabel(site: Site) {
  if (site.status === 'published') return 'Published'
  if (site.status === 'archived') return 'Archived'
  return 'Draft'
}

function statusClasses(site: Site) {
  if (site.status === 'published') return 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400'
  if (site.status === 'archived') return 'bg-muted text-muted-foreground'
  return 'bg-brand-gold/15 text-foreground'
}

function Modal({
  title,
  description,
  onClose,
  children,
}: {
  title: string
  description?: string
  onClose: () => void
  children: React.ReactNode
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-0 sm:items-center sm:p-4">
      <div role="dialog" aria-modal="true" aria-label={title} className="max-h-[92vh] w-full overflow-y-auto rounded-t-2xl border border-border bg-background p-5 shadow-2xl sm:max-w-lg sm:rounded-2xl sm:p-6">
        <div className="flex items-start justify-between gap-4">
          <div><h2 className="text-lg font-semibold">{title}</h2>{description && <p className="mt-1 text-sm leading-5 text-muted-foreground">{description}</p>}</div>
          <button type="button" onClick={onClose} aria-label="Close dialog" className="rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"><X className="size-4" /></button>
        </div>
        <div className="mt-6">{children}</div>
      </div>
    </div>
  )
}

function TrialBanner({ trial }: { trial: TrialStatus }) {
  if (trial.state === 'active') {
    return (
      <div className="flex flex-col gap-4 rounded-2xl border border-brand-gold/35 bg-brand-gold/10 p-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-3">
          <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-brand-gold/25 text-foreground"><Sparkles className="size-5" /></div>
          <div><p className="font-semibold">Your PERFI-SITE free trial is active</p><p className="mt-1 text-sm text-muted-foreground">{trial.daysRemaining} {trial.daysRemaining === 1 ? 'day' : 'days'} remaining. It started when you published your first website on {trial.startedAt ? formatDate(trial.startedAt) : 'your first publish'}.</p></div>
        </div>
        <span className="shrink-0 text-sm font-bold text-foreground">{trial.daysRemaining} days left</span>
      </div>
    )
  }
  if (trial.state === 'expired') {
    return (
      <div className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-5 sm:flex-row sm:items-center">
        <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-muted text-muted-foreground"><CalendarDays className="size-5" /></div>
        <div><p className="font-semibold">Your free trial has ended</p><p className="mt-1 text-sm text-muted-foreground">Your websites remain available as drafts. No paid subscription or payment status is connected yet.</p></div>
      </div>
    )
  }
  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-primary/20 bg-primary/5 p-5 sm:flex-row sm:items-center">
      <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary"><CalendarDays className="size-5" /></div>
      <div><p className="font-semibold">Publish your first website to start your free trial</p><p className="mt-1 text-sm text-muted-foreground">You will get 7 days from the first successful publish. No payment or subscription is being charged here.</p></div>
    </div>
  )
}

function SiteCard({
  site,
  onDuplicate,
  onArchive,
  onRestore,
  onSettings,
  onPublish,
  onUnpublish,
}: {
  site: Site
  onDuplicate: (site: Site) => void
  onArchive: (site: Site) => void
  onRestore: (site: Site) => void
  onSettings: (site: Site) => void
  onPublish: (site: Site) => void
  onUnpublish: (site: Site) => void
}) {
  const [menuOpen, setMenuOpen] = useState(false)
  const isArchived = site.status === 'archived'
  return (
    <article className={cn('rounded-2xl border border-border bg-card p-5 transition-shadow hover:shadow-md', isArchived && 'opacity-75')}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 items-start gap-3">
          <div className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary"><PanelsTopLeft className="size-5" /></div>
          <div className="min-w-0"><h2 className="truncate font-semibold">{site.name}</h2><p className="mt-1 flex items-center gap-1 truncate text-xs text-muted-foreground"><Globe2 className="size-3" /> {site.subdomain}</p></div>
        </div>
        <div className="relative">
          <button type="button" onClick={() => setMenuOpen((open) => !open)} className="rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground" aria-label={`More actions for ${site.name}`}><MoreHorizontal className="size-4" /></button>
          {menuOpen && <div className="absolute right-0 z-10 mt-1 w-44 rounded-lg border border-border bg-background p-1 shadow-xl">
            <button type="button" onClick={() => { setMenuOpen(false); onSettings(site) }} className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-xs hover:bg-muted"><Settings2 className="size-3.5" /> Website settings</button>
            <button type="button" onClick={() => { setMenuOpen(false); onDuplicate(site) }} className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-xs hover:bg-muted"><Copy className="size-3.5" /> Duplicate website</button>
            {isArchived ? <button type="button" onClick={() => { setMenuOpen(false); onRestore(site) }} className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-xs hover:bg-muted"><RotateCcw className="size-3.5" /> Restore website</button> : <button type="button" onClick={() => { setMenuOpen(false); onArchive(site) }} className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-xs text-destructive hover:bg-destructive/10"><Archive className="size-3.5" /> Archive website</button>}
          </div>}
        </div>
      </div>
      <div className="mt-5 flex flex-wrap items-center gap-2 text-xs">
        <span className={cn('rounded-full px-2.5 py-1 font-semibold', statusClasses(site))}>{statusLabel(site)}</span>
        <span className="rounded-full bg-muted px-2.5 py-1 text-muted-foreground">{site.buildMode === 'ai' ? 'AI build' : 'Manual build'}</span>
      </div>
      <div className="mt-5 grid grid-cols-2 gap-3 border-y border-border py-4 text-xs">
        <div><p className="text-muted-foreground">Created</p><p className="mt-1 font-medium">{formatDate(site.createdAt)}</p></div>
        <div><p className="text-muted-foreground">Last updated</p><p className="mt-1 font-medium">{formatDate(site.updatedAt)}</p></div>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {!isArchived && <Link href={`/dashboard/builder/manual?siteId=${encodeURIComponent(site.id)}`} className={cn(buttonVariants({ size: 'sm' }), 'flex-1')}><Pencil className="size-3.5" /> Edit</Link>}
        <Link href={`/dashboard/builder/manual/preview?siteId=${encodeURIComponent(site.id)}`} className={cn(buttonVariants({ variant: 'outline', size: 'sm' }), 'flex-1')}><Eye className="size-3.5" /> Preview</Link>
        {!isArchived && (site.status === 'published' ? <Button variant="outline" size="sm" onClick={() => onUnpublish(site)} className="w-full sm:w-auto"><ArrowUpRight className="size-3.5 rotate-180" /> Unpublish</Button> : <Button variant="outline" size="sm" onClick={() => onPublish(site)} className="w-full sm:w-auto"><Check className="size-3.5" /> Publish</Button>)}
      </div>
    </article>
  )
}

export function SitesManager() {
  const router = useRouter()
  const [sites, setSites] = useState<Site[]>([])
  const [trial, setTrial] = useState<TrialStatus>(localSiteRepository.getTrialStatus())
  const [filter, setFilter] = useState<SiteFilter>('active')
  const [showCreate, setShowCreate] = useState(false)
  const [settingsSite, setSettingsSite] = useState<Site | null>(null)
  const [archiveSite, setArchiveSite] = useState<Site | null>(null)
  const [notice, setNotice] = useState('')
  const [newName, setNewName] = useState('')
  const [newTemplate, setNewTemplate] = useState<ManualTemplate>('business')
  const [settingsName, setSettingsName] = useState('')
  const [settingsSubdomain, setSettingsSubdomain] = useState('')

  const refresh = () => {
    setSites(localSiteRepository.listSites())
    setTrial(localSiteRepository.getTrialStatus())
  }

  useEffect(() => {
    refresh()
    const onStorage = () => refresh()
    window.addEventListener('storage', onStorage)
    return () => window.removeEventListener('storage', onStorage)
  }, [])

  useEffect(() => {
    if (!notice) return
    const timeout = window.setTimeout(() => setNotice(''), 2800)
    return () => window.clearTimeout(timeout)
  }, [notice])

  const visibleSites = useMemo(() => sites.filter((site) => filter === 'archived' ? site.status === 'archived' : site.status !== 'archived'), [filter, sites])
  const activeCount = sites.filter((site) => site.status !== 'archived').length
  const publishedCount = sites.filter((site) => site.status === 'published').length

  const openSettings = (site: Site) => {
    setSettingsSite(site)
    setSettingsName(site.name)
    setSettingsSubdomain(site.subdomain.replace(/\.perfi-site\.com$/, ''))
  }
  const saveSettings = () => {
    if (!settingsSite || !settingsName.trim()) return
    localSiteRepository.updateSite({
      ...settingsSite,
      name: settingsName.trim(),
      subdomain: `${slugify(settingsSubdomain || settingsName)}.perfi-site.com`,
      updatedAt: new Date().toISOString(),
    })
    setSettingsSite(null)
    refresh()
    setNotice('Website settings saved')
  }
  const createWebsite = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!newName.trim()) return
    const site = localSiteRepository.createSite({ name: newName.trim(), template: newTemplate, buildMode: 'manual' })
    setShowCreate(false)
    setNewName('')
    router.push(`/dashboard/builder/manual?siteId=${encodeURIComponent(site.id)}`)
  }
  const duplicateWebsite = (site: Site) => {
    const duplicate = localSiteRepository.duplicateSite(site.id)
    if (duplicate) { refresh(); setNotice(`${duplicate.name} created as a draft`) }
  }
  const publishWebsite = (site: Site) => {
    const published = localSiteRepository.publishSite(site.id)
    if (published) { refresh(); setNotice('Website published and saved as a published draft') }
  }
  const unpublishWebsite = (site: Site) => {
    const unpublished = localSiteRepository.unpublishSite(site.id)
    if (unpublished) { refresh(); setNotice('Website moved back to draft') }
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div><p className="text-xs font-semibold uppercase tracking-[0.16em] text-brand-gold">Website workspace</p><h1 className="mt-2 text-2xl font-bold">My Sites</h1><p className="mt-1 text-sm text-muted-foreground">Create, edit, preview and publish every PERFI-SITE website in one place.</p></div>
        <Button onClick={() => setShowCreate(true)}><Plus className="size-4" /> Create website</Button>
      </div>
      <TrialBanner trial={trial} />
      <div className="grid gap-3 sm:grid-cols-3">
        <div className="rounded-xl border border-border bg-card p-4"><p className="text-xs text-muted-foreground">Websites</p><p className="mt-1 text-2xl font-bold">{activeCount}</p></div>
        <div className="rounded-xl border border-border bg-card p-4"><p className="text-xs text-muted-foreground">Published</p><p className="mt-1 text-2xl font-bold">{publishedCount}</p></div>
        <div className="rounded-xl border border-border bg-card p-4"><p className="text-xs text-muted-foreground">Trial</p><p className="mt-1 text-lg font-bold">{trial.state === 'active' ? `${trial.daysRemaining} days left` : trial.state === 'expired' ? 'Ended' : 'Not started'}</p></div>
      </div>
      <div className="flex items-center gap-1 rounded-lg bg-muted p-1 sm:w-fit">
        {([['active', `Active websites (${activeCount})`], ['archived', `Archived (${sites.length - activeCount})`]] as const).map(([value, label]) => <button key={value} type="button" onClick={() => setFilter(value)} className={cn('rounded-md px-3 py-2 text-xs font-medium', filter === value ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground')}>{label}</button>)}
      </div>
      {visibleSites.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-card px-6 py-16 text-center">
          {filter === 'active' ? <><LayoutTemplate className="mx-auto size-9 text-muted-foreground" /><h2 className="mt-4 font-semibold">Your website workspace is empty</h2><p className="mx-auto mt-2 max-w-md text-sm leading-6 text-muted-foreground">Start with a manual template, customize it in the visual builder, then publish when it is ready.</p><Button className="mt-5" onClick={() => setShowCreate(true)}><Plus className="size-4" /> Create your first website</Button></> : <><Archive className="mx-auto size-9 text-muted-foreground" /><h2 className="mt-4 font-semibold">No archived websites</h2><p className="mt-2 text-sm text-muted-foreground">Archived websites will appear here.</p></>}
        </div>
      ) : <div className="grid gap-4 xl:grid-cols-2">{visibleSites.map((site) => <SiteCard key={site.id} site={site} onDuplicate={duplicateWebsite} onArchive={setArchiveSite} onRestore={(item) => { localSiteRepository.restoreSite(item.id); refresh(); setNotice('Website restored to drafts') }} onSettings={openSettings} onPublish={publishWebsite} onUnpublish={unpublishWebsite} />)}</div>}
      <div className="flex items-start gap-3 rounded-xl border border-border bg-muted/40 p-4 text-xs leading-5 text-muted-foreground"><Sparkles className="mt-0.5 size-4 shrink-0 text-brand-gold" /><p>Website content is currently stored locally for development. Supabase persistence, hosting, domains, payments and AI services will connect through the repository interfaces later—no live subscription or payment status is being claimed here.</p></div>
      {notice && <div role="status" className="fixed bottom-5 left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 rounded-full bg-sidebar px-4 py-2.5 text-xs font-medium text-sidebar-foreground shadow-xl"><Check className="size-3.5 text-brand-gold" /> {notice}</div>}
      {showCreate && <Modal title="Create a new website" description="Choose a starting template. You can change every section in the manual builder." onClose={() => setShowCreate(false)}>
        <form onSubmit={createWebsite} className="space-y-5">
          <label className="block space-y-2"><span className="text-sm font-semibold">Website name</span><input autoFocus required value={newName} onChange={(event) => setNewName(event.target.value)} placeholder="e.g. Aster Studio" className="h-11 w-full rounded-lg border border-border bg-background px-3 text-sm outline-none focus:border-primary" /><span className="text-xs text-muted-foreground">This name is only used inside your PERFI-SITE workspace.</span></label>
          <fieldset><legend className="text-sm font-semibold">Starting template</legend><div className="mt-3 grid gap-2 sm:grid-cols-3">{([['business', 'Business', 'A complete multi-page starter'], ['portfolio', 'Portfolio', 'A visual showcase starter'], ['blank', 'Blank', 'A minimal home page']] as const).map(([value, label, description]) => <label key={value} className={cn('cursor-pointer rounded-xl border p-3 transition-colors', newTemplate === value ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/40')}><input type="radio" name="template" value={value} checked={newTemplate === value} onChange={() => setNewTemplate(value)} className="sr-only" /><span className="flex items-center gap-2 text-sm font-semibold">{newTemplate === value ? <Check className="size-3.5 text-primary" /> : <span className="size-3.5 rounded-full border border-border" />}{label}</span><span className="mt-1 block text-[11px] leading-4 text-muted-foreground">{description}</span></label>)}</div></fieldset>
          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end"><Button type="button" variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button><Button type="submit"><Plus className="size-4" /> Create and edit</Button></div>
        </form>
      </Modal>}
      {settingsSite && <Modal title="Website settings" description="Update the workspace name and PERFI-SITE subdomain." onClose={() => setSettingsSite(null)}>
        <div className="space-y-5">
          <label className="block space-y-2"><span className="text-sm font-semibold">Website name</span><input value={settingsName} onChange={(event) => setSettingsName(event.target.value)} className="h-11 w-full rounded-lg border border-border bg-background px-3 text-sm outline-none focus:border-primary" /></label>
          <label className="block space-y-2"><span className="text-sm font-semibold">PERFI-SITE subdomain</span><div className="flex h-11 items-center rounded-lg border border-border bg-background px-3 text-sm"><input value={settingsSubdomain} onChange={(event) => setSettingsSubdomain(event.target.value.replace(/[^a-zA-Z0-9-]/g, '-'))} className="min-w-0 flex-1 bg-transparent outline-none" /><span className="shrink-0 text-muted-foreground">.perfi-site.com</span></div><span className="text-xs text-muted-foreground">Custom domain connections are not active yet.</span></label>
          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end"><Button type="button" variant="outline" onClick={() => setSettingsSite(null)}>Cancel</Button><Button type="button" onClick={saveSettings}><Check className="size-4" /> Save settings</Button></div>
        </div>
      </Modal>}
      {archiveSite && <Modal title="Archive this website?" description={`“${archiveSite.name}” will leave your active sites list. Its content will be preserved and can be restored later.`} onClose={() => setArchiveSite(null)}>
        <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end"><Button variant="outline" onClick={() => setArchiveSite(null)}>Cancel</Button><Button variant="destructive" onClick={() => { localSiteRepository.archiveSite(archiveSite.id); setArchiveSite(null); refresh(); setNotice('Website archived') }}><Archive className="size-4" /> Archive website</Button></div>
      </Modal>}
    </div>
  )
}