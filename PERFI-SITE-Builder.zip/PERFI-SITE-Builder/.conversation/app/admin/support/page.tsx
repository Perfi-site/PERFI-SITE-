import { LifeBuoy } from 'lucide-react'
import { StagedFeature } from '@/components/dashboard/staged-feature'

export const metadata = { title: 'Support' }

export default function AdminSupportPage() {
  return (
    <StagedFeature
      title="Support"
      description="Handle customer support tickets and inquiries."
      icon={LifeBuoy}
      points={[
        'Ticket queue and assignment',
        'Priority and SLA tracking',
        'Canned responses',
        'Customer conversation history',
        'Escalation workflows',
        'Support performance metrics',
      ]}
    />
  )
}
