import { PanelsTopLeft } from 'lucide-react'
import { StagedFeature } from '@/components/dashboard/staged-feature'

export const metadata = { title: 'Sites' }

export default function AdminSitesPage() {
  return (
    <StagedFeature
      title="Sites"
      description="Oversee all websites across the platform."
      icon={PanelsTopLeft}
      points={[
        'All customer sites',
        'Published vs draft status',
        'Hosting usage per site',
        'Content moderation',
        'Suspend abusive sites',
        'Performance monitoring',
      ]}
    />
  )
}
