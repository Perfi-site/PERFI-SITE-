import { Briefcase } from 'lucide-react'
import { StagedFeature } from '@/components/dashboard/staged-feature'

export const metadata = { title: 'Service Orders' }

export default function AdminOrdersPage() {
  return (
    <StagedFeature
      title="Service Orders"
      description="Manage PERFI TECH professional service orders."
      icon={Briefcase}
      points={[
        'Incoming service requests',
        'Assign to team members',
        'Quote and pricing approval',
        'Delivery status tracking',
        'Customer messaging',
        'Completed order archive',
      ]}
    />
  )
}
