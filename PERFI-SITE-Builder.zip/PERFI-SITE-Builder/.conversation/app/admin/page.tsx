import type { Metadata } from 'next'
import { Users, PanelsTopLeft, Briefcase, CreditCard } from 'lucide-react'
import { StatCard } from '@/components/dashboard/stat-card'

export const metadata = {
  title: 'Admin Dashboard',
}

const recentSignups = [
  { name: 'Awaiting data', email: 'Connect the database to populate', plan: '—' },
]

export default function AdminDashboardPage() {
  return (
    <div className="flex flex-col gap-8">
      <div>
        <h1 className="text-2xl font-bold">Admin overview</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Platform-wide metrics for PERFI-SITE. Live figures connect with the database stage.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Total customers" value="0" hint="Across all plans" icon={Users} />
        <StatCard label="Published sites" value="0" hint="Live on hosting" icon={PanelsTopLeft} />
        <StatCard label="Service orders" value="0" hint="Pending & active" icon={Briefcase} />
        <StatCard label="MRR" value="$0" hint="Monthly recurring" icon={CreditCard} />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="rounded-2xl border border-border bg-card p-6 lg:col-span-2">
          <h2 className="text-lg font-semibold">Recent signups</h2>
          <div className="mt-5 overflow-hidden rounded-xl border border-border">
            <table className="w-full text-left text-sm">
              <thead className="bg-muted/60 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 font-medium">Customer</th>
                  <th className="px-4 py-3 font-medium">Email</th>
                  <th className="px-4 py-3 font-medium">Plan</th>
                </tr>
              </thead>
              <tbody>
                {recentSignups.map((row, i) => (
                  <tr key={i} className="border-t border-border">
                    <td className="px-4 py-3 font-medium">{row.name}</td>
                    <td className="px-4 py-3 text-muted-foreground">{row.email}</td>
                    <td className="px-4 py-3 text-muted-foreground">{row.plan}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-card p-6">
          <h2 className="text-lg font-semibold">Platform health</h2>
          <ul className="mt-5 space-y-4">
            {[
              { label: 'Hosting edge network', status: 'Pending integration' },
              { label: 'Payments provider', status: 'Pending integration' },
              { label: 'Domain registrar', status: 'Pending integration' },
              { label: 'Database (Supabase)', status: 'Pending integration' },
            ].map((item) => (
              <li key={item.label} className="flex items-center justify-between gap-3">
                <span className="text-sm text-muted-foreground">{item.label}</span>
                <span className="inline-flex items-center gap-1.5 rounded-full bg-brand-gold/15 px-2.5 py-0.5 text-xs font-medium text-[oklch(0.5_0.11_80)]">
                  <span className="size-1.5 rounded-full bg-brand-gold" />
                  {item.status}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  )
}
