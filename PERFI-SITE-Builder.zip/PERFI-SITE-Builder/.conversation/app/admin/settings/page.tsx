import { Settings } from 'lucide-react'
import { StagedFeature } from '@/components/dashboard/staged-feature'

export const metadata = { title: 'Platform Settings' }

export default function AdminSettingsPage() {
  return (
    <StagedFeature
      title="Platform Settings"
      description="Configure platform-wide settings and integrations."
      icon={Settings}
      points={[
        'Pricing and plan management',
        'Service catalog configuration',
        'Integration credentials',
        'Team members and roles',
        'Branding and defaults',
        'Feature flags',
      ]}
    />
  )
}
