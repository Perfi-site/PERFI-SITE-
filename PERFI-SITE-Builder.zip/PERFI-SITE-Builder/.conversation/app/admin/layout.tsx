'use client'

import type { ReactNode } from 'react'
import {
  LayoutGrid,
  Users,
  PanelsTopLeft,
  Globe,
  Briefcase,
  FileText,
  LifeBuoy,
  CreditCard,
  Settings,
} from 'lucide-react'
import { DashboardShell, type DashboardNavItem } from '@/components/dashboard/dashboard-shell'

const navItems: DashboardNavItem[] = [
  { label: 'Overview', href: '/admin', icon: LayoutGrid },
  { label: 'Customers', href: '/admin/customers', icon: Users },
  { label: 'Sites', href: '/admin/sites', icon: PanelsTopLeft },
  { label: 'Domains', href: '/admin/domains', icon: Globe },
  { label: 'Service Orders', href: '/admin/orders', icon: Briefcase },
  { label: 'Subscriptions', href: '/admin/subscriptions', icon: CreditCard },
  { label: 'Invoices', href: '/admin/invoices', icon: FileText },
  { label: 'Support', href: '/admin/support', icon: LifeBuoy },
  { label: 'Settings', href: '/admin/settings', icon: Settings },
]

export default function AdminLayout({ children }: { children: ReactNode }) {
  return (
    <DashboardShell navItems={navItems} roleLabel="Administrator" userName="Admin">
      {children}
    </DashboardShell>
  )
}
