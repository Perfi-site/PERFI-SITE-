import { CreditCard } from 'lucide-react'
import { StagedFeature } from '@/components/dashboard/staged-feature'

export const metadata = { title: 'Subscriptions' }

export default function AdminSubscriptionsPage() {
  return (
    <StagedFeature
      title="Subscriptions"
      description="Track and manage recurring subscriptions."
      icon={CreditCard}
      points={[
        'Active subscriptions by plan',
        'Monthly vs annual breakdown',
        'MRR and churn metrics',
        'Upgrades and downgrades',
        'Past-due accounts',
        'Plan configuration',
      ]}
    />
  )
}
