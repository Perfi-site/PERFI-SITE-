import { FileText } from 'lucide-react'
import { StagedFeature } from '@/components/dashboard/staged-feature'

export const metadata = { title: 'Invoices' }

export default function AdminInvoicesPage() {
  return (
    <StagedFeature
      title="Invoices"
      description="Oversee billing and payments across the platform."
      icon={FileText}
      points={[
        'All customer invoices',
        'Paid, open and overdue status',
        'Revenue reporting',
        'Refunds and adjustments',
        'Payout reconciliation',
        'Export for accounting',
      ]}
    />
  )
}
