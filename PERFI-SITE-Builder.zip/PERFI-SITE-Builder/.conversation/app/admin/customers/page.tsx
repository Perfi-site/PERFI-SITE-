import { Users } from 'lucide-react'
import { StagedFeature } from '@/components/dashboard/staged-feature'

export const metadata = { title: 'Customers' }

export default function AdminCustomersPage() {
  return (
    <StagedFeature
      title="Customers"
      description="Manage every PERFI-SITE customer account."
      icon={Users}
      points={[
        'Customer directory and search',
        'Account details and roles',
        'Plan and subscription status',
        'Suspend or reactivate accounts',
        'Impersonate for support',
        'Activity logs',
      ]}
    />
  )
}
