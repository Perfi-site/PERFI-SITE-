import { Globe } from 'lucide-react'
import { StagedFeature } from '@/components/dashboard/staged-feature'

export const metadata = { title: 'Domains' }

export default function AdminDomainsPage() {
  return (
    <StagedFeature
      title="Domains"
      description="Manage all registered and connected domains."
      icon={Globe}
      points={[
        'Registered domain inventory',
        'Renewal and expiry tracking',
        'DNS troubleshooting',
        'Transfer requests',
        'Registrar reconciliation',
        'SSL status',
      ]}
    />
  )
}
