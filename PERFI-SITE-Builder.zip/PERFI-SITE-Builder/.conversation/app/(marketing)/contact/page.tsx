import type { Metadata } from 'next'
import { Mail, LifeBuoy, Building2 } from 'lucide-react'
import { PageHero } from '@/components/marketing/page-hero'
import { ContactForm } from '@/components/contact/contact-form'
import { company } from '@/lib/config'

export const metadata: Metadata = {
  title: 'Contact',
  description: 'Get in touch with the PERFI TECH team for sales, support and partnerships.',
}

const channels = [
  {
    icon: Mail,
    title: 'General & sales',
    detail: company.email,
  },
  {
    icon: LifeBuoy,
    title: 'Customer support',
    detail: company.supportEmail,
  },
  {
    icon: Building2,
    title: 'Company',
    detail: company.legalName,
  },
]

export default function ContactPage() {
  return (
    <>
      <PageHero
        eyebrow="Contact"
        title="Let's build something global"
        description="Questions about the platform, services or partnerships? Send us a message and our team will get back to you."
      />

      <section className="mx-auto grid w-full max-w-6xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[1fr_1.4fr]">
        <div className="flex flex-col gap-4">
          {channels.map((channel) => (
            <div
              key={channel.title}
              className="flex items-start gap-4 rounded-xl border border-border bg-card p-5"
            >
              <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <channel.icon className="size-5" aria-hidden="true" />
              </div>
              <div>
                <h3 className="font-semibold">{channel.title}</h3>
                <p className="mt-0.5 text-sm text-muted-foreground">{channel.detail}</p>
              </div>
            </div>
          ))}
          <p className="mt-2 text-sm text-muted-foreground">
            Existing customers can also open tickets from the{' '}
            <span className="font-medium text-foreground">customer dashboard</span>.
          </p>
        </div>

        <ContactForm />
      </section>
    </>
  )
}
