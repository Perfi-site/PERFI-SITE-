import type { Metadata } from 'next'
import { PageHero } from '@/components/marketing/page-hero'
import { company } from '@/lib/config'

export const metadata: Metadata = {
  title: 'About',
  description:
    'PERFI-SITE is the website-building, hosting, domain and services platform from PERFI TECH GLOBAL VENTURE LIMITED.',
}

const values = [
  {
    title: 'Innovate',
    body: 'We build modern tools — including AI — that make professional web presence accessible to everyone.',
  },
  {
    title: 'Invest',
    body: 'We invest in reliability, security and performance so your business is always online and fast.',
  },
  {
    title: 'Build',
    body: 'From a single prompt or a blank canvas, we give you everything to build exactly what you imagine.',
  },
  {
    title: 'Grow',
    body: 'Commerce, analytics and expert services help you turn a website into a growing global business.',
  },
]

export default function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="About us"
        title="Technology that helps the world build"
        description={`${company.product} is the all-in-one platform from ${company.legalName} — bringing website building, hosting, domains, e-commerce and professional services together.`}
      />

      <section className="mx-auto w-full max-w-4xl px-4 py-16 sm:px-6">
        <div className="prose-none space-y-6 text-lg leading-relaxed text-muted-foreground">
          <p>
            {company.legalName} is a global technology company on a mission to help
            individuals, entrepreneurs and enterprises establish and grow their digital
            presence. {company.product} is our flagship platform for creating, launching,
            hosting and scaling professional websites.
          </p>
          <p>
            Whether you build with AI in seconds or craft every detail manually, {company.product}{' '}
            handles publishing, hosting, domains, commerce and analytics — while giving you
            direct access to PERFI TECH{`'s`} professional services team when you need
            expert help.
          </p>
        </div>

        <div className="mt-14 grid gap-4 sm:grid-cols-2">
          {values.map((value) => (
            <div key={value.title} className="rounded-xl border border-border bg-card p-6">
              <h3 className="text-xl font-semibold text-primary">{value.title}</h3>
              <p className="mt-2 leading-relaxed text-muted-foreground">{value.body}</p>
            </div>
          ))}
        </div>

        <div className="mt-14 rounded-2xl border border-border bg-brand-blue-dark p-8 text-center text-white">
          <p className="text-sm font-medium tracking-[0.15em] text-brand-gold">
            {company.tagline}
          </p>
          <p className="mt-3 text-lg text-white/80">
            One platform. Global ambition. Built for what you create next.
          </p>
        </div>
      </section>
    </>
  )
}
