import type { Metadata } from 'next'
import { PageHero } from '@/components/marketing/page-hero'
import { Icon } from '@/components/icon'
import { products } from '@/lib/config'

export const metadata: Metadata = {
  title: 'Products',
  description:
    'Explore the PERFI-SITE platform: AI builder, manual builder, hosting, domains, e-commerce and analytics.',
}

export default function ProductsPage() {
  return (
    <>
      <PageHero
        eyebrow="The platform"
        title="One platform, every capability"
        description="PERFI-SITE combines the tools you need to create, publish, host and grow — no plugins or patchwork required."
      />

      <section className="mx-auto w-full max-w-5xl px-4 py-16 sm:px-6">
        <div className="flex flex-col gap-6">
          {products.map((product, index) => (
            <div
              key={product.id}
              id={product.id}
              className="grid scroll-mt-24 items-center gap-6 rounded-2xl border border-border bg-card p-6 sm:grid-cols-[auto_1fr] sm:p-8"
            >
              <div className="flex size-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-brand-blue-dark text-white">
                <Icon name={product.icon} className="size-7" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-3">
                  <h2 className="text-2xl font-semibold">{product.name}</h2>
                  <span className="rounded-full bg-brand-gold/15 px-2.5 py-0.5 text-xs font-medium text-[oklch(0.5_0.11_80)]">
                    {product.tagline}
                  </span>
                </div>
                <p className="mt-3 text-pretty leading-relaxed text-muted-foreground">
                  {product.description}
                </p>
                <p className="mt-3 text-xs font-medium uppercase tracking-wider text-muted-foreground/70">
                  Module {String(index + 1).padStart(2, '0')} · Integration-ready
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </>
  )
}
