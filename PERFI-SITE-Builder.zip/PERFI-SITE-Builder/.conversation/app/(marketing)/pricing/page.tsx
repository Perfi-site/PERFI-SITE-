import type { Metadata } from 'next'
import { PageHero } from '@/components/marketing/page-hero'
import { PricingTable } from '@/components/pricing/pricing-table'

export const metadata: Metadata = {
  title: 'Pricing',
  description:
    'Simple PERFI-SITE plans: Starter at $5/month, Business at $10/month and Professional at $20/month, with yearly savings.',
}

export default function PricingPage() {
  return (
    <>
      <PageHero
        eyebrow="Pricing"
        title="Get your business online"
        description="Choose a simple plan with clear monthly or yearly pricing. Every plan includes the AI and manual builders, secure hosting and free SSL."
      />

      <section className="mx-auto w-full max-w-6xl px-4 py-16 sm:px-6">
        <PricingTable />
        <p className="mt-10 text-center text-sm text-muted-foreground">
          Prices shown in USD. Your 7-day free trial starts after your first successful
          website publish. Checkout and subscription management will connect to a real
          payment provider later.
        </p>
      </section>
    </>
  )
}
