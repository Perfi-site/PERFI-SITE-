import { Hero } from '@/components/home/hero'
import { StatsBand } from '@/components/home/stats-band'
import { FeatureGrid } from '@/components/home/feature-grid'
import { ServicesPreview } from '@/components/home/services-preview'
import { FinalCta } from '@/components/home/final-cta'

export default function HomePage() {
  return (
    <>
      <Hero />
      <StatsBand />
      <FeatureGrid />
      <ServicesPreview />
      <FinalCta />
    </>
  )
}
