import type { Metadata } from 'next'
import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { cn } from '@/lib/utils'
import { buttonVariants } from '@/components/ui/button'
import { PageHero } from '@/components/marketing/page-hero'
import { Icon } from '@/components/icon'
import { services } from '@/lib/config'

export const metadata: Metadata = {
  title: 'Services',
  description:
    'Order professional technology and business services from PERFI TECH — branding, development, SEO, store setup, migration and consulting.',
}

export default function ServicesPage() {
  return (
    <>
      <PageHero
        eyebrow="PERFI TECH Services"
        title="Professional services, on demand"
        description="Order expert help directly from the PERFI TECH team. Every service integrates with your PERFI-SITE account for seamless delivery, invoicing and support."
      />

      <section className="mx-auto w-full max-w-6xl px-4 py-16 sm:px-6">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => (
            <div
              key={service.id}
              className="flex flex-col rounded-xl border border-border bg-card p-6 transition-all hover:border-primary/40 hover:shadow-lg hover:shadow-primary/5"
            >
              <div className="flex size-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <Icon name={service.icon} className="size-5" />
              </div>
              <h3 className="mt-5 text-lg font-semibold">{service.name}</h3>
              <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">
                {service.description}
              </p>
              <div className="mt-5 flex items-center justify-between">
                <span className="text-sm text-muted-foreground">
                  From{' '}
                  <span className="font-semibold text-foreground">
                    ${service.startingPrice}
                  </span>
                </span>
                <Link
                  href="/signup"
                  className={cn(buttonVariants({ variant: 'outline', size: 'sm' }))}
                >
                  Order
                  <ArrowRight className="ml-1 size-3.5" />
                </Link>
              </div>
            </div>
          ))}
        </div>

        <p className="mt-10 text-center text-sm text-muted-foreground">
          Service ordering, quotes and delivery tracking are managed from your{' '}
          <Link href="/dashboard" className="font-medium text-primary hover:underline">
            customer dashboard
          </Link>
          .
        </p>
      </section>
    </>
  )
}
