import type { ReactNode } from 'react'
import { Logo } from '@/components/logo'
import { company } from '@/lib/config'

export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative hidden flex-col justify-between overflow-hidden bg-brand-blue-dark p-10 text-white lg:flex">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-24 top-10 size-80 rounded-full bg-brand-gold/15 blur-3xl"
        />
        <Logo invert />
        <div className="relative max-w-md">
          <h2 className="text-3xl font-bold leading-tight">
            Build. Publish. Grow. — all with PERFI-SITE
          </h2>
          <p className="mt-4 text-white/70">
            Join the platform that brings website building, hosting, domains, commerce and
            professional services together.
          </p>
        </div>
        <p className="relative text-xs font-medium tracking-[0.15em] text-brand-gold">
          {company.tagline}
        </p>
      </div>

      <div className="flex items-center justify-center p-6 sm:p-10">
        <div className="w-full max-w-sm">{children}</div>
      </div>
    </div>
  )
}
