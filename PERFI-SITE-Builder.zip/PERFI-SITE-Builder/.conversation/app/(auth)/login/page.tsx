import type { Metadata } from 'next'
import { Logo } from '@/components/logo'
import { AuthForm } from '@/components/auth/auth-form'

export const metadata: Metadata = {
  title: 'Log In',
  description: 'Log in to your PERFI-SITE account.',
}

export default function LoginPage() {
  return (
    <div className="flex flex-col gap-8">
      <div className="lg:hidden">
        <Logo />
      </div>
      <div>
        <h1 className="text-2xl font-bold">Welcome back</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Log in to manage your sites, services and account.
        </p>
      </div>
      <AuthForm mode="login" />
    </div>
  )
}
