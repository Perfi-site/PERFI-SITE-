import type { Metadata } from 'next'
import { Logo } from '@/components/logo'
import { AuthForm } from '@/components/auth/auth-form'

export const metadata: Metadata = {
  title: 'Sign Up',
  description: 'Create your PERFI-SITE account and start building.',
}

export default function SignupPage() {
  return (
    <div className="flex flex-col gap-8">
      <div className="lg:hidden">
        <Logo />
      </div>
      <div>
        <h1 className="text-2xl font-bold">Create your account</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Start building, publishing and growing with PERFI-SITE.
        </p>
      </div>
      <AuthForm mode="signup" />
    </div>
  )
}
