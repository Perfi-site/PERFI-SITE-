import { ManualBuilder } from '@/components/builder/manual-builder'

export const metadata = { title: 'Manual Builder' }

export default function ManualBuilderPage() {
  return <ManualBuilder />
}
