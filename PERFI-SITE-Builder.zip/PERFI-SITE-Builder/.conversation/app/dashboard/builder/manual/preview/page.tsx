'use client'

import { useEffect, useState } from 'react'
import { Eye, ArrowLeft } from 'lucide-react'
import Link from 'next/link'
import { getSite, loadDraft } from '@/lib/builder/storage'
import { createSite } from '@/lib/builder/factory'
import type { Site } from '@/lib/builder/types'
import { SiteRenderer } from '@/components/builder/site-renderer'

export default function WebsitePreviewPage() {
  const [site, setSite] = useState<Site | null>(null)

  useEffect(() => {
    const siteId = new URLSearchParams(window.location.search).get('siteId')
    setSite((siteId ? getSite(siteId) : null) ?? loadDraft() ?? createSite({ name: 'My first website', buildMode: 'manual', template: 'business' }))
  }, [])

  if (!site) return <div className="flex min-h-screen items-center justify-center text-sm text-muted-foreground">Loading preview…</div>
  const page = site.pages[0]

  return (
    <div className="min-h-screen bg-muted/50 p-4 sm:p-8">
      <div className="mx-auto max-w-6xl overflow-hidden rounded-xl bg-background shadow-xl">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <div className="flex items-center gap-2 text-sm font-semibold"><Eye className="size-4 text-primary" /> {site.name}<span className="rounded-full bg-muted px-2 py-1 text-[10px] font-normal text-muted-foreground">Preview</span></div>
          <Link href="/dashboard/builder/manual" className="flex items-center gap-1.5 text-xs font-semibold text-primary hover:underline"><ArrowLeft className="size-3.5" /> Back to builder</Link>
        </div>
        <SiteRenderer site={site} page={page} preview />
      </div>
    </div>
  )
}