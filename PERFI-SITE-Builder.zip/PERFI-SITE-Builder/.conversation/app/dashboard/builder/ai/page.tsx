import { Sparkles } from 'lucide-react'
import { StagedFeature } from '@/components/dashboard/staged-feature'

export const metadata = { title: 'AI Website Builder' }

export default function AiBuilderPage() {
  return (
    <StagedFeature
      title="Build with AI"
      description="Describe your website and generate a complete, on-brand site."
      icon={Sparkles}
      points={[
        'Prompt-to-website generation',
        'AI copywriting and layout',
        'Brand color and font selection',
        'Section-by-section editing',
        'Image generation',
        'One-click publish',
      ]}
    />
  )
}
