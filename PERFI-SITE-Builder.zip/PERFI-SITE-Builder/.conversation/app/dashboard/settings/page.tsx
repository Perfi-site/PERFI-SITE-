import { Settings } from 'lucide-react'
import { StagedFeature } from '@/components/dashboard/staged-feature'

export const metadata = { title: 'Settings' }

export default function SettingsPage() {
  return (
    <StagedFeature
      title="Account Settings"
      description="Manage your profile, security and preferences."
      icon={Settings}
      points={[
        'Profile and contact details',
        'Password and security',
        'Two-factor authentication',
        'Notification preferences',
        'Subscription management',
        'Danger zone',
      ]}
    />
  )
}
