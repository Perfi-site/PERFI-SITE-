import { LifeBuoy } from 'lucide-react'
import { StagedFeature } from '@/components/dashboard/staged-feature'

export const metadata = { title: 'Support' }

export default function SupportPage() {
  return (
    <StagedFeature
      title="Customer Support"
      description="Get help from the PERFI TECH team."
      icon={LifeBuoy}
      points={[
        'Open support tickets',
        'Live chat',
        'Knowledge base',
        'Ticket status tracking',
        'Priority support tiers',
        'Service-level updates',
      ]}
    />
  )
}
