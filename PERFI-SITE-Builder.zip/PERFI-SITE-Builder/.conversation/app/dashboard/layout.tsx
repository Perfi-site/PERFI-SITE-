'use client'

import type { ReactNode } from 'react'
import {
  LayoutGrid,
  Globe,
  Server,
  ShoppingCart,
  BarChart3,
  Briefcase,
  FileText,
  LifeBuoy,
  Settings,
  PanelsTopLeft,
} from 'lucide-react'
import { DashboardShell, type DashboardNavItem } from '@/components/dashboard/dashboard-shell'

const navItems: DashboardNavItem[] = [
  { label: 'Overview', href: '/dashboard', icon: LayoutGrid },
  { label: 'My Sites', href: '/dashboard/sites', icon: PanelsTopLeft },
  { label: 'Domains', href: '/dashboard/domains', icon: Globe },
  { label: 'Hosting', href: '/dashboard/hosting', icon: Server },
  { label: 'E-commerce', href: '/dashboard/ecommerce', icon: ShoppingCart },
  { label: 'Analytics', href: '/dashboard/analytics', icon: BarChart3 },
  { label: 'Services', href: '/dashboard/services', icon: Briefcase },
  { label: 'Invoices', href: '/dashboard/invoices', icon: FileText },
  { label: 'Support', href: '/dashboard/support', icon: LifeBuoy },
  { label: 'Settings', href: '/dashboard/settings', icon: Settings },
]

export default function DashboardLayout({ children }: { children: ReactNode }) {
  return (
    <DashboardShell navItems={navItems} roleLabel="Customer" userName="Jane Doe">
      {children}
    </DashboardShell>
  )
}
