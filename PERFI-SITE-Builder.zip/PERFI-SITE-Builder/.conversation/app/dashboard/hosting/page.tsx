import { Server } from 'lucide-react'
import { StagedFeature } from '@/components/dashboard/staged-feature'

export const metadata = { title: 'Hosting' }

export default function HostingPage() {
  return (
    <StagedFeature
      title="Hosting & Publishing"
      description="Publish to a fast, secure global edge network."
      icon={Server}
      points={[
        'One-click publishing',
        'Global edge delivery',
        'Free SSL certificates',
        'Automatic backups',
        'Bandwidth and storage usage',
        'Deployment history',
      ]}
    />
  )
}
