import type { Metadata } from 'next'
import Link from 'next/link'
import {
  Sparkles,
  LayoutTemplate,
  Globe,
  Briefcase,
  PanelsTopLeft,
  FileText,
  CreditCard,
  ArrowUpRight,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { buttonVariants } from '@/components/ui/button'
import { StatCard } from '@/components/dashboard/stat-card'
import { PlanStatusCard } from '@/components/dashboard/plan-status-card'

export const metadata: Metadata = {
  title: 'Customer Dashboard',
}

const quickActions = [
  { label: 'Build with AI', href: '/dashboard/builder/ai', icon: Sparkles },
  { label: 'Build Manually', href: '/dashboard/builder/manual', icon: LayoutTemplate },
  { label: 'Search Domain', href: '/dashboard/domains', icon: Globe },
  { label: 'Order Services', href: '/dashboard/services', icon: Briefcase },
]

export default function CustomerDashboardPage() {
  return (
    <div className="flex flex-col gap-8">
      <div>
        <h1 className="text-2xl font-bold">Welcome back, Jane</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Here&apos;s an overview of your PERFI-SITE account.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {quickActions.map((action) => (
          <Link
            key={action.label}
            href={action.href}
            className="group flex items-center gap-3 rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/40 hover:shadow-md"
          >
            <div className="flex size-10 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <action.icon className="size-5" aria-hidden="true" />
            </div>
            <span className="text-sm font-medium">{action.label}</span>
            <ArrowUpRight className="ml-auto size-4 text-muted-foreground transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
          </Link>
        ))}
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Active sites" value="0" hint="Build your first site" icon={PanelsTopLeft} />
        <StatCard label="Domains" value="0" hint="No domains yet" icon={Globe} />
        <StatCard label="Subscription" value="—" hint="Choose a plan" icon={CreditCard} />
        <StatCard label="Open invoices" value="0" hint="All settled" icon={FileText} />
      </div>

      <PlanStatusCard />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="rounded-2xl border border-border bg-card p-6 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Your sites</h2>
            <Link
              href="/dashboard/sites"
              className={cn(buttonVariants({ variant: 'outline', size: 'sm' }))}
            >
              View all
            </Link>
          </div>
          <div className="mt-6 flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-border py-12 text-center">
            <PanelsTopLeft className="size-8 text-muted-foreground" aria-hidden="true" />
            <p className="text-sm text-muted-foreground">You haven&apos;t created a site yet.</p>
            <Link
              href="/dashboard/builder/ai"
              className={cn(buttonVariants({ size: 'sm' }))}
            >
              <Sparkles className="mr-1 size-3.5" />
              Build with AI
            </Link>
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-card p-6">
          <h2 className="text-lg font-semibold">Getting started</h2>
          <ol className="mt-6 space-y-4">
            {[
              'Create your first website',
              'Connect or register a domain',
              'Publish to global hosting',
              'Track visits with analytics',
            ].map((step, i) => (
              <li key={step} className="flex items-start gap-3">
                <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
                  {i + 1}
                </span>
                <span className="text-sm text-muted-foreground">{step}</span>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </div>
  )
}
