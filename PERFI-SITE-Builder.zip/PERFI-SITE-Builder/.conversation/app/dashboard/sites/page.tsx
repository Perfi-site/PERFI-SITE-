import { SitesManager } from '@/components/dashboard/sites-manager'

export const metadata = { title: 'My Sites' }

export default function SitesPage() {
  return <SitesManager />
}
