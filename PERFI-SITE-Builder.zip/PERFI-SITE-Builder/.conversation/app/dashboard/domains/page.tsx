import { Globe } from 'lucide-react'
import { StagedFeature } from '@/components/dashboard/staged-feature'

export const metadata = { title: 'Domains' }

export default function DomainsPage() {
  return (
    <StagedFeature
      title="Domain Search & Management"
      description="Search, register and manage domains for your sites."
      icon={Globe}
      points={[
        'Real-time domain availability search',
        'Domain registration',
        'DNS record management',
        'Auto-renewal',
        'Connect existing domains',
        'SSL provisioning',
      ]}
    />
  )
}
