import { ShoppingCart } from 'lucide-react'
import { StagedFeature } from '@/components/dashboard/staged-feature'

export const metadata = { title: 'E-commerce' }

export default function EcommercePage() {
  return (
    <StagedFeature
      title="E-commerce"
      description="Sell products and services across your sites."
      icon={ShoppingCart}
      points={[
        'Product catalog management',
        'Cart and checkout',
        'Order management',
        'Inventory tracking',
        'Discounts and coupons',
        'Global tax and shipping',
      ]}
    />
  )
}
