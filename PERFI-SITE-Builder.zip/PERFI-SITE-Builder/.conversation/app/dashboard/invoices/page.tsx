import { FileText } from 'lucide-react'
import { StagedFeature } from '@/components/dashboard/staged-feature'

export const metadata = { title: 'Invoices' }

export default function InvoicesPage() {
  return (
    <StagedFeature
      title="Invoices & Payments"
      description="View invoices and manage your billing."
      icon={FileText}
      points={[
        'Subscription invoices',
        'Service order invoices',
        'Downloadable PDF receipts',
        'Payment methods',
        'Billing history',
        'Auto-pay settings',
      ]}
    />
  )
}
