import { BarChart3 } from 'lucide-react'
import { StagedFeature } from '@/components/dashboard/staged-feature'

export const metadata = { title: 'Analytics' }

export default function AnalyticsPage() {
  return (
    <StagedFeature
      title="Website Analytics"
      description="Understand your traffic, audience and conversions."
      icon={BarChart3}
      points={[
        'Real-time visitor tracking',
        'Traffic sources',
        'Audience demographics',
        'Conversion tracking',
        'Page performance',
        'Exportable reports',
      ]}
    />
  )
}
