import { Briefcase } from 'lucide-react'
import { StagedFeature } from '@/components/dashboard/staged-feature'

export const metadata = { title: 'Services' }

export default function DashboardServicesPage() {
  return (
    <StagedFeature
      title="PERFI TECH Services"
      description="Order and track professional services for your projects."
      icon={Briefcase}
      points={[
        'Browse the service marketplace',
        'Request quotes',
        'Order and pay',
        'Track delivery status',
        'Message the services team',
        'Review past orders',
      ]}
    />
  )
}
