import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Inter, Space_Grotesk } from 'next/font/google'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-space-grotesk',
  display: 'swap',
})

export const metadata: Metadata = {
  title: {
    default: 'PERFI-SITE — Build. Publish. Grow.',
    template: '%s | PERFI-SITE',
  },
  description:
    'PERFI-SITE is an all-in-one platform to create, launch, host and grow your professional website — powered by PERFI TECH GLOBAL VENTURE LIMITED.',
  keywords: [
    'PERFI-SITE',
    'PERFI TECH',
    'AI website builder',
    'website hosting',
    'domain search',
    'ecommerce',
    'SaaS',
  ],
  authors: [{ name: 'PERFI TECH GLOBAL VENTURE LIMITED' }],
  generator: 'v0.app',
}

export const viewport: Viewport = {
  colorScheme: 'light dark',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
    { media: '(prefers-color-scheme: dark)', color: '#141a2e' },
  ],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${spaceGrotesk.variable}`}>
      <body className="antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
